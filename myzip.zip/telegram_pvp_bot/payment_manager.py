from datetime import datetime
from sqlalchemy.orm import Session
from database import User, DepositRequest, WithdrawRequest, Transaction
import logging

logger = logging.getLogger(__name__)

class PaymentManager:
    def __init__(self, db: Session):
        self.db = db
    
    # ============ DEPOSIT METHODS ============
    
    def create_deposit_request(self, user_id: int, username: str, amount: int, currency: str, method: str, screenshot: str = None) -> bool:
        """Create a deposit request"""
        try:
            deposit = DepositRequest(
                user_id=user_id,
                username=username,
                amount=amount,
                currency=currency,
                method=method,
                screenshot=screenshot,
                status='pending'
            )
            self.db.add(deposit)
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error creating deposit request: {e}")
            return False
    
    def get_deposit_history(self, user_id: int, limit: int = 20) -> list:
        """Get user's deposit history"""
        try:
            deposits = self.db.query(DepositRequest).filter(
                DepositRequest.user_id == user_id
            ).order_by(DepositRequest.created_at.desc()).limit(limit).all()
            
            return [{
                'id': d.id,
                'amount': d.amount,
                'currency': d.currency,
                'method': d.method,
                'status': d.status,
                'created_at': d.created_at,
                'processed_at': d.processed_at
            } for d in deposits]
        except Exception as e:
            logger.error(f"Error getting deposit history: {e}")
            return []
    
    def get_pending_deposits(self) -> list:
        """Get all pending deposit requests"""
        try:
            deposits = self.db.query(DepositRequest).filter(
                DepositRequest.status == 'pending'
            ).order_by(DepositRequest.created_at.desc()).all()
            
            return [{
                'id': d.id,
                'user_id': d.user_id,
                'username': d.username,
                'amount': d.amount,
                'currency': d.currency,
                'method': d.method,
                'screenshot': d.screenshot,
                'created_at': d.created_at
            } for d in deposits]
        except Exception as e:
            logger.error(f"Error getting pending deposits: {e}")
            return []
    
    def approve_deposit(self, deposit_id: int) -> bool:
        """Approve a deposit and add balance to user"""
        try:
            deposit = self.db.query(DepositRequest).filter(DepositRequest.id == deposit_id).first()
            if not deposit or deposit.status != 'pending':
                return False
            
            deposit.status = 'approved'
            deposit.processed_at = datetime.utcnow()
            
            # Add balance to user
            user = self.db.query(User).filter(User.user_id == deposit.user_id).first()
            if user:
                if deposit.currency == 'INR':
                    user.wallet_balance_inr = (user.wallet_balance_inr or 0) + deposit.amount
                    user.total_deposited_inr = (user.total_deposited_inr or 0) + deposit.amount
                else:
                    user.wallet_balance_usd = (user.wallet_balance_usd or 0) + deposit.amount
                    user.total_deposited_usd = (user.total_deposited_usd or 0) + deposit.amount
                
                # Add transaction record
                self._add_transaction(
                    deposit.user_id, 
                    'deposit', 
                    deposit.amount, 
                    deposit.currency, 
                    f"Deposit approved - {deposit.method}"
                )
            
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error approving deposit: {e}")
            self.db.rollback()
            return False
    
    def reject_deposit(self, deposit_id: int, reason: str = None) -> bool:
        """Reject a deposit request"""
        try:
            deposit = self.db.query(DepositRequest).filter(DepositRequest.id == deposit_id).first()
            if not deposit or deposit.status != 'pending':
                return False
            
            deposit.status = 'rejected'
            deposit.admin_notes = reason
            deposit.processed_at = datetime.utcnow()
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error rejecting deposit: {e}")
            self.db.rollback()
            return False
    
    # ============ WITHDRAW METHODS ============
    
    def create_withdraw_request(self, user_id: int, username: str, amount: int, currency: str, method: str, 
                                 upi_id: str = None, bank_name: str = None, 
                                 account_number: str = None, ifsc_code: str = None,
                                 crypto_address: str = None) -> bool:
        """Create a withdraw request"""
        try:
            withdraw = WithdrawRequest(
                user_id=user_id,
                username=username,
                amount=amount,
                currency=currency,
                method=method,
                upi_id=upi_id,
                bank_name=bank_name,
                account_number=account_number,
                ifsc_code=ifsc_code,
                crypto_address=crypto_address,
                status='pending'
            )
            self.db.add(withdraw)
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error creating withdraw request: {e}")
            self.db.rollback()
            return False
    
    def get_withdraw_history(self, user_id: int, limit: int = 20) -> list:
        """Get user's withdraw history"""
        try:
            withdraws = self.db.query(WithdrawRequest).filter(
                WithdrawRequest.user_id == user_id
            ).order_by(WithdrawRequest.created_at.desc()).limit(limit).all()
            
            return [{
                'id': w.id,
                'amount': w.amount,
                'currency': w.currency,
                'method': w.method,
                'status': w.status,
                'created_at': w.created_at,
                'processed_at': w.processed_at
            } for w in withdraws]
        except Exception as e:
            logger.error(f"Error getting withdraw history: {e}")
            return []
    
    def get_pending_withdraws(self) -> list:
        """Get all pending withdraw requests"""
        try:
            withdraws = self.db.query(WithdrawRequest).filter(
                WithdrawRequest.status == 'pending'
            ).order_by(WithdrawRequest.created_at.desc()).all()
            
            return [{
                'id': w.id,
                'user_id': w.user_id,
                'username': w.username,
                'amount': w.amount,
                'currency': w.currency,
                'method': w.method,
                'upi_id': w.upi_id,
                'bank_name': w.bank_name,
                'account_number': w.account_number,
                'ifsc_code': w.ifsc_code,
                'crypto_address': w.crypto_address,
                'created_at': w.created_at
            } for w in withdraws]
        except Exception as e:
            logger.error(f"Error getting pending withdraws: {e}")
            return []
    
    def approve_withdraw(self, withdraw_id: int) -> bool:
        """Approve a withdraw request"""
        try:
            withdraw = self.db.query(WithdrawRequest).filter(WithdrawRequest.id == withdraw_id).first()
            if not withdraw or withdraw.status != 'pending':
                return False
            
            withdraw.status = 'approved'
            withdraw.processed_at = datetime.utcnow()
            
            # Add transaction record
            user = self.db.query(User).filter(User.user_id == withdraw.user_id).first()
            if user:
                self._add_transaction(
                    withdraw.user_id, 
                    'withdraw_approved', 
                    -withdraw.amount, 
                    withdraw.currency, 
                    f"Withdraw approved - {withdraw.method}"
                )
            
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error approving withdraw: {e}")
            self.db.rollback()
            return False
    
    def complete_withdraw(self, withdraw_id: int) -> bool:
        """Mark withdraw as completed"""
        try:
            withdraw = self.db.query(WithdrawRequest).filter(WithdrawRequest.id == withdraw_id).first()
            if not withdraw or withdraw.status != 'approved':
                return False
            
            withdraw.status = 'completed'
            withdraw.processed_at = datetime.utcnow()
            
            # Update user totals
            user = self.db.query(User).filter(User.user_id == withdraw.user_id).first()
            if user:
                if withdraw.currency == 'INR':
                    user.total_withdrawn_inr = (user.total_withdrawn_inr or 0) + withdraw.amount
                else:
                    user.total_withdrawn_usd = (user.total_withdrawn_usd or 0) + withdraw.amount
                
                self._add_transaction(
                    withdraw.user_id, 
                    'withdraw_completed', 
                    -withdraw.amount, 
                    withdraw.currency, 
                    f"Withdraw completed - {withdraw.method}"
                )
            
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error completing withdraw: {e}")
            self.db.rollback()
            return False
    
    def reject_withdraw(self, withdraw_id: int, reason: str = None) -> bool:
        """Reject a withdraw request and refund"""
        try:
            withdraw = self.db.query(WithdrawRequest).filter(WithdrawRequest.id == withdraw_id).first()
            if not withdraw or withdraw.status != 'pending':
                return False
            
            # Refund amount
            user = self.db.query(User).filter(User.user_id == withdraw.user_id).first()
            if user:
                if withdraw.currency == 'INR':
                    user.wallet_balance_inr = (user.wallet_balance_inr or 0) + withdraw.amount
                else:
                    user.wallet_balance_usd = (user.wallet_balance_usd or 0) + withdraw.amount
                
                self._add_transaction(
                    withdraw.user_id, 
                    'withdraw_refund', 
                    withdraw.amount, 
                    withdraw.currency, 
                    f"Withdraw rejected - refunded"
                )
            
            withdraw.status = 'rejected'
            withdraw.admin_notes = reason
            withdraw.processed_at = datetime.utcnow()
            self.db.commit()
            return True
        except Exception as e:
            logger.error(f"Error rejecting withdraw: {e}")
            self.db.rollback()
            return False
    
    # ============ TRANSACTION HISTORY ============
    
    def get_transaction_history(self, user_id: int, limit: int = 50) -> list:
        """Get user's transaction history"""
        try:
            transactions = self.db.query(Transaction).filter(
                Transaction.user_id == user_id
            ).order_by(Transaction.created_at.desc()).limit(limit).all()
            
            return [{
                'id': t.id,
                'type': t.type,
                'amount': t.amount,
                'currency': t.currency,
                'balance_after': t.balance_after,
                'description': t.description,
                'reference_id': t.reference_id,
                'created_at': t.created_at
            } for t in transactions]
        except Exception as e:
            logger.error(f"Error getting transaction history: {e}")
            return []
    
    # ============ PRIVATE METHODS ============
    
    def _add_transaction(self, user_id: int, type: str, amount: int, currency: str, description: str):
        """Add transaction record"""
        try:
            # Get current balance
            user = self.db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return
            
            balance_after = user.wallet_balance_inr if currency == 'INR' else user.wallet_balance_usd
            
            transaction = Transaction(
                user_id=user_id,
                type=type,
                amount=amount,
                currency=currency,
                balance_after=balance_after or 0,
                description=description
            )
            self.db.add(transaction)
            self.db.commit()
        except Exception as e:
            logger.error(f"Error adding transaction: {e}")
            self.db.rollback()