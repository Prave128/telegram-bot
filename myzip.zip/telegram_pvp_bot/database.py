from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, BigInteger, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from config import DATABASE_URL

Base = declarative_base()
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, unique=True, nullable=False)
    username = Column(String, unique=True)
    first_name = Column(String)
    last_name = Column(String)
    currency = Column(String, default='INR')
    coins = Column(Integer, default=100)
    
    wallet_balance_inr = Column(Integer, default=10000)
    wallet_balance_usd = Column(Integer, default=100)
    
    total_deposited_inr = Column(Integer, default=0)
    total_deposited_usd = Column(Integer, default=0)
    total_withdrawn_inr = Column(Integer, default=0)
    total_withdrawn_usd = Column(Integer, default=0)
    total_won_inr = Column(Integer, default=0)
    total_won_usd = Column(Integer, default=0)
    total_lost_inr = Column(Integer, default=0)
    total_lost_usd = Column(Integer, default=0)
    
    total_games = Column(Integer, default=0)
    total_wins = Column(Integer, default=0)
    total_losses = Column(Integer, default=0)
    total_draws = Column(Integer, default=0)
    total_earnings = Column(Integer, default=0)
    rating = Column(Float, default=1200)
    level = Column(Integer, default=1)
    experience = Column(Integer, default=0)
    
    referral_code = Column(String, unique=True)
    daily_bonus_claimed = Column(DateTime, nullable=True)
    last_active = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_banned = Column(Boolean, default=False)

class DepositRequest(Base):
    __tablename__ = 'deposit_requests'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger)
    username = Column(String)
    amount = Column(Integer)  # in paise/cents
    currency = Column(String)
    method = Column(String)  # UPI, BTC, ETH, USDT, Bank
    screenshot = Column(String, nullable=True)  # File path
    transaction_id = Column(String, nullable=True)
    status = Column(String, default='pending')  # pending, approved, rejected, completed
    admin_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)

class WithdrawRequest(Base):
    __tablename__ = 'withdraw_requests'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger)
    username = Column(String)
    amount = Column(Integer)  # in paise/cents
    currency = Column(String)
    method = Column(String)  # UPI, Bank, Crypto
    upi_id = Column(String, nullable=True)
    bank_name = Column(String, nullable=True)
    account_number = Column(String, nullable=True)
    ifsc_code = Column(String, nullable=True)
    crypto_address = Column(String, nullable=True)
    status = Column(String, default='pending')
    admin_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)

class Transaction(Base):
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger)
    type = Column(String)  # deposit, withdraw, game_win, game_loss, bonus, tip
    amount = Column(Integer)
    currency = Column(String)
    balance_after = Column(Integer)
    description = Column(String)
    reference_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

def init_db():
    Base.metadata.create_all(engine)

def get_db():
    return SessionLocal()

class DatabaseContext:
    def __enter__(self):
        self.db = SessionLocal()
        return self.db
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.db.close()

def get_db_context():
    return DatabaseContext()