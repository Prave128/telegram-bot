# pvp_handlers.py
# pvp_handlers.py
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import logging

from config import INR_BET_AMOUNTS, USD_BET_AMOUNTS, ROUNDS_OPTIONS
from database import get_user_currency, get_user_balance, get_user_profile, update_wallet, add_transaction
from game_manager import GameManager

logger = logging.getLogger(__name__)
game_manager = GameManager()

def get_brand_header():
    return """
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  🎰 CASINO INDIA  🎰              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
"""

async def pvp_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show PVP menu with bet amount selection"""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    currency = get_user_currency(user_id)
    symbol = '₹' if currency == 'INR' else '$'
    
    # Check if user has a pending challenge
    pending = game_manager.get_user_pending_challenge(user_id)
    if pending:
        await query.edit_message_text(
            f"""
{get_brand_header()}

⏳ **You have a pending challenge!**

From: {pending['challenger_id']}
Bet: {symbol}{pending['bet_amount']}
Game: {pending['game_type'].upper()}
Rounds: {pending.get('rounds_type', '3R1W').upper()}

Please check your DM to accept or decline.
            """
        )
        return
    
    # Check if user is in an active game
    game_id = game_manager.get_user_game(user_id)
    if game_id:
        await query.edit_message_text(
            f"""
{get_brand_header()}

🎲 **You are in an active game!**

Use /roll to play.
            """
        )
        return
    
    # Show bet amount selection
    keyboard = []
    bet_amounts = INR_BET_AMOUNTS if currency == 'INR' else USD_BET_AMOUNTS
    
    row = []
    for i, amount in enumerate(bet_amounts):
        row.append(InlineKeyboardButton(f"{symbol}{amount}", callback_data=f"pvp_bet_{amount}"))
        if (i + 1) % 3 == 0:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("✏️ Custom Amount", callback_data="pvp_custom_bet")])
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="back_to_main")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = f"""
{get_brand_header()}

⚔️ **PVP DICE GAME**

Select bet amount:

💰 Currency: {currency}
📌 Min: {symbol}{min(bet_amounts)}
📌 Max: {symbol}{max(bet_amounts)}

💡 You'll challenge another player
🎯 Winner gets 85% of the pot
🏢 Platform fee: 15%
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup)

async def pvp_bet_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle bet amount selection"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "pvp_custom_bet":
        await query.edit_message_text(
            f"""
{get_brand_header()}

✏️ **Custom Bet Amount**

Send the bet amount as a message.
Example: 75

Please send the amount now.
            """
        )
        context.user_data['awaiting_custom_bet'] = True
        return
    
    # Extract bet amount
    bet_amount = int(data.replace('pvp_bet_', ''))
    context.user_data['pvp_bet_amount'] = bet_amount
    context.user_data['currency'] = get_user_currency(update.effective_user.id)
    
    # Show rounds options
    await show_rounds_options(update, context)

async def show_rounds_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show rounds selection after bet amount is set"""
    query = update.callback_query
    if query:
        await query.answer()
        edit_func = query.edit_message_text
    else:
        edit_func = update.message.reply_text
    
    bet_amount = context.user_data.get('pvp_bet_amount', 10)
    currency = context.user_data.get('currency', 'INR')
    symbol = '₹' if currency == 'INR' else '$'
    
    keyboard = []
    for option in ROUNDS_OPTIONS:
        keyboard.append([InlineKeyboardButton(
            f"🎲 {option['label']}", 
            callback_data=f"pvp_rounds_{option['key']}"
        )])
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="pvp_menu")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = f"""
{get_brand_header()}

🎯 **Select Rounds**

Bet Amount: {symbol}{bet_amount}

Choose how many rolls each player gets:

• 2R1W - 2 rolls, highest total wins
• 3R1W - 3 rolls, highest total wins
• 4R1W - 4 rolls, highest total wins
• 5R1W - 5 rolls, highest total wins

💰 Winner gets 85% of the pot
    """
    
    await edit_func(text, reply_markup=reply_markup)

async def pvp_rounds_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle rounds selection"""
    query = update.callback_query
    await query.answer()
    
    rounds_key = query.data.replace('pvp_rounds_', '')
    bet_amount = context.user_data.get('pvp_bet_amount', 10)
    currency = context.user_data.get('currency', 'INR')
    symbol = '₹' if currency == 'INR' else '$'
    
    # Find the rounds details
    rounds_detail = next((r for r in ROUNDS_OPTIONS if r['key'] == rounds_key), None)
    rolls = rounds_detail['rolls'] if rounds_detail else 3
    
    # Store in user data
    context.user_data['pvp_rounds'] = rounds_key
    context.user_data['pvp_rolls'] = rolls
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

👥 **Challenge a Player**

Send: `/challenge @username`

Example: `/challenge @john`

📋 **Game Details:**
Game: Dice PVP
Bet: {symbol}{bet_amount}
Rounds: {rounds_key.upper()} ({rolls} rolls each)

💡 The challenged player will receive your challenge.
        """
    )

async def handle_custom_bet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle custom bet amount from user message"""
    if not context.user_data.get('awaiting_custom_bet'):
        return
    
    try:
        amount = int(update.message.text.strip())
        if amount <= 0:
            await update.message.reply_text("❌ Amount must be greater than 0!")
            return
        
        currency = get_user_currency(update.effective_user.id)
        max_amount = 200 if currency == 'INR' else 10
        
        if amount > max_amount:
            await update.message.reply_text(f"❌ Maximum amount is {max_amount}!")
            return
        
        context.user_data['pvp_bet_amount'] = amount
        context.user_data['currency'] = currency
        context.user_data['awaiting_custom_bet'] = False
        
        # Show rounds options
        await show_rounds_options(update, context)
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number!")

async def pvp_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show PVP game history"""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    history = game_manager.get_pvp_history(user_id, limit=10)
    
    if not history:
        await query.edit_message_text(
            f"""
{get_brand_header()}

📜 **No PVP History Found**

You haven't played any PVP games yet.
Start a game by going to Games → PVP!
            """
        )
        return
    
    text = f"""
{get_brand_header()}

📜 **PVP GAME HISTORY**

"""
    for game in history:
        symbol = '₹' if game['currency'] == 'INR' else '$'
        winner = game['winner_id']
        is_winner = winner == user_id
        
        status = "🏆 WON" if is_winner and winner else "❌ LOST" if winner else "🤝 DRAW"
        
        text += f"""
🎲 {game['rounds_type'].upper()}
Bet: {symbol}{game['bet_amount']}
Status: {status}
📅 {game['created_at'][:10] if game['created_at'] else 'N/A'}
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="games_menu")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')