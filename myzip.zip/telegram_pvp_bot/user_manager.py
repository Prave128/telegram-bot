from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database import User, WithdrawRequest
import random
import string
import logging

logger = logging.getLogger(__name__)

class UserManager:
    def __init__(self, db: Session):
        self.db = db
    
    def get_or_create_user(self, user_id: int, username: str, first_name: str, last_name: str = None):
        user = self.db.query(User).filter(User.user_id == user_id).first()
        
        if not user:
            referral_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            user = User(
                user_id=user_id,
                username=username,
                first_name=first_name,
                last_name=last_name,
                coins=100,
                wallet_balance_inr=10000,
                wallet_balance_usd=100,
                referral_code=referral_code
            )
            self.db.add(user)
            self.db.commit()
            self.db.refresh(user)
        
        return user
    
    def set_currency(self, user_id: int, currency: str) -> bool:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False
        user.currency = currency
        self.db.commit()
        return True
    
    def get_user_profile(self, user_id: int) -> dict:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return None
        
        return {
            'username': f"@{user.username}" if user.username else user.first_name,
            'first_name': user.first_name,
            'coins': user.coins,
            'currency': user.currency,
            'wallet_balance_inr': user.wallet_balance_inr or 0,
            'wallet_balance_usd': user.wallet_balance_usd or 0,
            'total_games': user.total_games,
            'total_wins': user.total_wins,
            'total_losses': user.total_losses,
            'total_draws': user.total_draws,
            'rating': user.rating,
            'level': user.level,
            'experience': user.experience,
            'referral_code': user.referral_code,
            'referral_count': 0,  # Add this line
            'daily_bonus_available': self.can_claim_daily_bonus(user_id)
        }
    
    def can_claim_daily_bonus(self, user_id: int) -> bool:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user or not user.daily_bonus_claimed:
            return True
        return (datetime.utcnow() - user.daily_bonus_claimed) >= timedelta(hours=24)
    
    def claim_daily_bonus(self, user_id: int):
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False, "User not found"
        
        if not self.can_claim_daily_bonus(user_id):
            return False, "Already claimed"
        
        user.wallet_balance_inr = (user.wallet_balance_inr or 0) + 5000
        user.wallet_balance_usd = (user.wallet_balance_usd or 0) + 100
        user.daily_bonus_claimed = datetime.utcnow()
        self.db.commit()
        return True, "Bonus claimed!"
    
    def get_wallet_balance(self, user_id: int, currency: str) -> int:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return 0
        return user.wallet_balance_inr if currency == 'INR' else user.wallet_balance_usd
    
    def add_wallet(self, user_id: int, amount: int, currency: str, reason: str) -> bool:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False
        
        if currency == 'INR':
            user.wallet_balance_inr = (user.wallet_balance_inr or 0) + amount
        else:
            user.wallet_balance_usd = (user.wallet_balance_usd or 0) + amount
        
        self.db.commit()
        return True
    
    def deduct_wallet(self, user_id: int, amount: int, currency: str, reason: str) -> bool:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False
        
        balance = self.get_wallet_balance(user_id, currency)
        if balance < amount:
            return False
        
        if currency == 'INR':
            user.wallet_balance_inr = (user.wallet_balance_inr or 0) - amount
        else:
            user.wallet_balance_usd = (user.wallet_balance_usd or 0) - amount
        
        self.db.commit()
        return True
    
    def add_coins(self, user_id: int, amount: int, reason: str) -> bool:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False
        user.coins += amount
        self.db.commit()
        return True
    
    def deduct_coins(self, user_id: int, amount: int, reason: str) -> bool:
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return False
        if user.coins < amount:
            return False
        user.coins -= amount
        self.db.commit()
        return True
    
    def update_stats(self, user_id: int, won: bool = None, draw: bool = False):
        user = self.db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return
        
        user.total_games += 1
        
        if draw:
            user.total_draws += 1
        elif won is True:
            user.total_wins += 1
            user.rating += 10
            user.experience += 20
        elif won is False:
            user.total_losses += 1
            user.rating -= 5
            user.experience += 5
        
        if user.experience >= user.level * 100:
            user.level += 1
        
        self.db.commit()
    
    def create_withdraw_request(self, user_id: int, username: str, amount: int, currency: str, upi_id: str) -> bool:
        balance = self.get_wallet_balance(user_id, currency)
        if balance < amount:
            return False
        
        if currency == 'INR':
            user = self.db.query(User).filter(User.user_id == user_id).first()
            user.wallet_balance_inr = (user.wallet_balance_inr or 0) - amount
        else:
            user = self.db.query(User).filter(User.user_id == user_id).first()
            user.wallet_balance_usd = (user.wallet_balance_usd or 0) - amount
        
        withdraw = WithdrawRequest(
            user_id=user_id,
            username=username,
            amount=amount,
            currency=currency,
            upi_id=upi_id
        )
        self.db.add(withdraw)
        self.db.commit()
        return True
    
    def tip_coins(self, sender_id: int, receiver_id: int, amount: int):
        sender = self.db.query(User).filter(User.user_id == sender_id).first()
        receiver = self.db.query(User).filter(User.user_id == receiver_id).first()
        
        if not sender or not receiver:
            return False, "User not found"
        if sender.coins < amount:
            return False, "Insufficient coins"
        
        sender.coins -= amount
        receiver.coins += amount
        self.db.commit()
        return True, f"Tipped {amount} coins!"