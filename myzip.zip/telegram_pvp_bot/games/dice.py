# games/dice.py
import random
from typing import Dict, Optional, List
from games.base_game import BaseGame

class DiceGame(BaseGame):
    """Dice game with PVP, Bot, and Solo modes"""
    
    def __init__(self):
        super().__init__()
        self.game_type = 'dice'
        self.max_rolls = 3
        self.rounds_type = None
        self.bet_amount = 0
        self.platform_fee = 0
        self.prize_pool = 0
        self.currency = 'INR'
        self.player1_username = "Player 1"
        self.player2_username = "Player 2"
        self.current_turn = None
        self.players = {}
        self.is_active = False
    
    def setup_game(self, rounds_type: str, rolls: int, bet_amount: int = 0, currency: str = 'INR'):
        """Setup game configuration"""
        self.rounds_type = rounds_type
        self.max_rolls = rolls
        self.bet_amount = bet_amount
        self.currency = currency
        self.platform_fee = int(bet_amount * 15 / 100) if bet_amount > 0 else 0
        self.prize_pool = bet_amount - self.platform_fee if bet_amount > 0 else 0
        return self
    
    def start_game(self, player1_id: int, player2_id: int = None) -> Dict:
        """Start a new dice game"""
        self.is_active = True
        self.players = {
            'player1': {
                'id': player1_id, 
                'score': 0, 
                'rolls': [], 
                'rolls_left': self.max_rolls
            },
            'player2': {
                'id': player2_id, 
                'score': 0, 
                'rolls': [], 
                'rolls_left': self.max_rolls
            } if player2_id else None
        }
        self.current_turn = 'player1'
        
        message = f"🎲 **DICE GAME STARTED!**\n\n"
        message += f"📋 Rounds: {self.rounds_type.upper()}\n"
        message += f"🎯 Rolls each: {self.max_rolls}\n"
        
        if self.bet_amount > 0:
            symbol = '₹' if self.currency == 'INR' else '$'
            message += f"💰 Bet: {symbol}{self.bet_amount}\n"
            message += f"🏆 Prize: {symbol}{self.prize_pool}\n"
            message += f"🏢 Platform Fee: {symbol}{self.platform_fee}\n\n"
        
        message += f"👤 Player 1: {self.player1_username}\n"
        if player2_id:
            message += f"👤 Player 2: {self.player2_username}\n\n"
            message += f"🔄 {self.player1_username}'s turn! Use /roll"
        else:
            message += f"\n🔄 {self.player1_username}'s turn! Use /roll"
        
        return {
            'message': message,
            'game_state': self.get_game_state()
        }
    
    def make_move(self, player_id: int, move_data: Dict = None) -> tuple:
        """Handle a dice roll"""
        if not self.is_active:
            return False, {'message': '❌ Game is over!'}
        
        # Find which player is rolling
        current = None
        player_key = None
        for key, player in self.players.items():
            if player and player.get('id') == player_id:
                current = player
                player_key = key
                break
        
        if not current:
            return False, {'message': '❌ You are not in this game!'}
        
        # Check if it's their turn
        if player_key != self.current_turn:
            other_key = 'player2' if player_key == 'player1' else 'player1'
            if self.players[other_key]:
                return False, {'message': f"❌ It's {self._get_player_name(other_key)}'s turn!"}
        
        # Check if they have rolls left
        if current['rolls_left'] <= 0:
            return False, {'message': '❌ You have no rolls left!'}
        
        # Roll the dice
        roll_value = random.randint(1, 6)
        current['rolls'].append(roll_value)
        current['score'] += roll_value
        current['rolls_left'] -= 1
        
        message = f"🎲 {self._get_player_name(player_key)} rolled: **{roll_value}**\n"
        message += f"📊 Total: **{current['score']}**\n"
        message += f"🎯 Rolls: {', '.join(map(str, current['rolls']))}\n"
        message += f"⚡ Rolls left: {current['rolls_left']}\n"
        
        # Check if player has finished their rolls
        if current['rolls_left'] == 0:
            # Check if other player has rolls left (PVP only)
            if self.mode == 'pvp' and self.players['player2']:
                other_key = 'player2' if player_key == 'player1' else 'player1'
                if self.players[other_key]['rolls_left'] > 0:
                    self.current_turn = other_key
                    message += f"\n🔄 Now it's {self._get_player_name(other_key)}'s turn!"
                else:
                    # Both players have finished
                    self.is_active = False
                    result = self.get_result()
                    message += f"\n\n🏆 **GAME OVER!**\n\n"
                    message += self._format_result(result)
                    return True, {
                        'message': message,
                        'game_state': self.get_game_state(),
                        'result': result
                    }
            else:
                # Bot or solo mode - game ends
                self.is_active = False
                result = self.get_result()
                message += f"\n\n🏆 **GAME OVER!**\n\n"
                message += self._format_result(result)
                return True, {
                    'message': message,
                    'game_state': self.get_game_state(),
                    'result': result
                }
        
        return True, {
            'message': message,
            'game_state': self.get_game_state()
        }
    
    def get_result(self) -> Dict:
        """Get game result with winner"""
        p1_score = self.players['player1']['score']
        p1_rolls = self.players['player1']['rolls']
        
        if self.mode == 'pvp' and self.players['player2']:
            p2_score = self.players['player2']['score']
            p2_rolls = self.players['player2']['rolls']
            
            if p1_score > p2_score:
                return {
                    'winner': 'player1',
                    'winner_id': self.players['player1']['id'],
                    'loser_id': self.players['player2']['id'],
                    'player1_score': p1_score,
                    'player2_score': p2_score,
                    'player1_rolls': p1_rolls,
                    'player2_rolls': p2_rolls,
                    'bet_amount': self.bet_amount,
                    'platform_fee': self.platform_fee,
                    'prize_pool': self.prize_pool,
                    'currency': self.currency
                }
            elif p2_score > p1_score:
                return {
                    'winner': 'player2',
                    'winner_id': self.players['player2']['id'],
                    'loser_id': self.players['player1']['id'],
                    'player1_score': p1_score,
                    'player2_score': p2_score,
                    'player1_rolls': p1_rolls,
                    'player2_rolls': p2_rolls,
                    'bet_amount': self.bet_amount,
                    'platform_fee': self.platform_fee,
                    'prize_pool': self.prize_pool,
                    'currency': self.currency
                }
            else:
                return {
                    'winner': None,
                    'winner_id': None,
                    'loser_id': None,
                    'player1_score': p1_score,
                    'player2_score': p2_score,
                    'player1_rolls': p1_rolls,
                    'player2_rolls': p2_rolls,
                    'bet_amount': self.bet_amount,
                    'platform_fee': 0,
                    'prize_pool': 0,
                    'currency': self.currency,
                    'is_draw': True
                }
        else:
            # Bot or solo mode
            return {
                'winner': 'player',
                'winner_id': self.players['player1']['id'],
                'player_score': p1_score,
                'player_rolls': p1_rolls,
                'currency': self.currency
            }
    
    def _format_result(self, result: Dict) -> str:
        """Format result message"""
        if self.mode == 'pvp':
            symbol = '₹' if self.currency == 'INR' else '$'
            message = f"👤 {self.player1_username}: **{result['player1_score']}** ({', '.join(map(str, result['player1_rolls']))})\n"
            message += f"👤 {self.player2_username}: **{result['player2_score']}** ({', '.join(map(str, result['player2_rolls']))})\n\n"
            
            if result.get('winner'):
                winner_name = self.player1_username if result['winner'] == 'player1' else self.player2_username
                message += f"🎉 **{winner_name} WINS!** 🎉\n"
                if result.get('prize_pool', 0) > 0:
                    message += f"💰 Prize: {symbol}{result['prize_pool']}\n"
                    message += f"🏢 Platform Fee: {symbol}{result['platform_fee']}"
            else:
                message += "🤝 **DRAW!**\n"
                message += f"💰 Both players get their money back!"
            return message
        
        elif self.mode == 'bot':
            return f"👤 Your Score: **{result['player_score']}**\n🎯 Rolls: {', '.join(map(str, result['player_rolls']))}"
        else:
            return f"👤 Your Score: **{result['player_score']}**\n🎯 Rolls: {', '.join(map(str, result['player_rolls']))}"
    
    def _get_player_name(self, player_key: str) -> str:
        """Get player name for display"""
        if player_key == 'player1':
            return self.player1_username
        else:
            return self.player2_username
    
    def get_game_state(self) -> Dict:
        """Get current game state"""
        state = {
            'game_id': self.game_id,
            'game_type': self.game_type,
            'mode': self.mode,
            'rounds_type': self.rounds_type,
            'max_rolls': self.max_rolls,
            'is_active': self.is_active,
            'current_turn': self.current_turn,
            'bet_amount': self.bet_amount,
            'platform_fee': self.platform_fee,
            'prize_pool': self.prize_pool,
            'currency': self.currency,
            'players': {
                'player1': {
                    'id': self.players['player1']['id'],
                    'score': self.players['player1']['score'],
                    'rolls': self.players['player1']['rolls'],
                    'rolls_left': self.players['player1']['rolls_left']
                }
            }
        }
        
        if self.players.get('player2'):
            state['players']['player2'] = {
                'id': self.players['player2']['id'],
                'score': self.players['player2']['score'],
                'rolls': self.players['player2']['rolls'],
                'rolls_left': self.players['player2']['rolls_left']
            }
        
        return state
    
    def reset_game(self):
        """Reset game state"""
        self.is_active = False
        self.players = {}
        self.current_turn = None