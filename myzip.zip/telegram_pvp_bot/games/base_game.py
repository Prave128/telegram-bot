from abc import ABC, abstractmethod
from typing import Dict, Tuple, Optional
from datetime import datetime

class BaseGame(ABC):
    def __init__(self):
        self.game_id = None
        self.game_type = None
        self.mode = None
        self.players = {}
        self.current_turn = None
        self.is_active = False
        self.entry_fee = 0
        self.prize_pool = 0
        self.start_time = None
        self.end_time = None
        self.winner = None
    
    @abstractmethod
    def start_game(self, player1_id: int, player2_id: Optional[int] = None) -> Dict:
        pass
    
    @abstractmethod
    def make_move(self, player_id: int, move_data: Dict) -> Tuple[bool, Dict]:
        pass
    
    @abstractmethod
    def get_game_state(self) -> Dict:
        pass
    
    @abstractmethod
    def get_result(self) -> Dict:
        pass
    
    @abstractmethod
    def reset_game(self):
        pass
    
    def is_turn(self, player_id: int) -> bool:
        return self.current_turn == player_id
    
    def end_game(self):
        self.is_active = False
        self.end_time = datetime.utcnow()
    
    def set_winner(self, player_id: int):
        self.winner = player_id
        self.end_game()