import random
from games.base_game import BaseGame

class ThrowballGame(BaseGame):
    def __init__(self):
        super().__init__()
        self.game_type = 'throwball'
        self.max_throws = 5
        self.targets = [
            {'name': 'Small', 'points': 10, 'size': 0.3},
            {'name': 'Medium', 'points': 6, 'size': 0.5},
            {'name': 'Large', 'points': 3, 'size': 0.8}
        ]
    
    def start_game(self, player1_id, player2_id=None):
        self.players = {
            'player1': {'id': player1_id, 'score': 0, 'throws': 0, 'hits': 0},
            'player2': {'id': player2_id, 'score': 0, 'throws': 0, 'hits': 0} if player2_id else None
        }
        self.current_turn = 'player1'
        self.is_active = True
        return {'message': "🎯 Throwball! 5 throws. Use /roll"}
    
    def make_move(self, player_id, move_data):
        if not self.is_active:
            return False, {'message': 'Game over!'}
        
        current = None
        if self.players['player1']['id'] == player_id:
            current = 'player1'
        elif self.players['player2'] and self.players['player2']['id'] == player_id:
            current = 'player2'
        
        if not current or current != self.current_turn:
            return False, {'message': 'Not your turn!'}
        
        if self.players[current]['throws'] >= self.max_throws:
            return False, {'message': 'No throws left!'}
        
        target = random.choice(self.targets)
        hit_probability = target['size'] + random.uniform(-0.2, 0.2)
        hit = random.random() < hit_probability
        points = target['points'] if hit else 0
        
        self.players[current]['score'] += points
        self.players[current]['throws'] += 1
        if hit:
            self.players[current]['hits'] += 1
        
        if self.players[current]['throws'] >= self.max_throws:
            self.is_active = False
            result = self.get_result()
            return True, {'message': f"🎯 Game Over!\n{self._format_result(result)}", 'result': result}
        
        if self.mode == 'pvp':
            self.current_turn = 'player2' if current == 'player1' else 'player1'
        
        return True, {'message': f"🎯 {'HIT! 🎉' if hit else 'MISS! ❌'}\nTarget: {target['name']}\nPoints: {points}\nTotal: {self.players[current]['score']}"}
    
    def get_result(self):
        if self.mode == 'pvp':
            p1 = self.players['player1']['score']
            p2 = self.players['player2']['score']
            return {'scores': {'player1': p1, 'player2': p2}, 'winner': 'player1' if p1 > p2 else 'player2' if p2 > p1 else None}
        return {'scores': {'player': self.players['player1']['score']}, 'winner': 'player'}
    
    def _format_result(self, result):
        if self.mode == 'pvp':
            return f"Player 1: {result['scores']['player1']}\nPlayer 2: {result['scores']['player2']}\n{'Winner: Player ' + result['winner'] if result['winner'] else 'Draw!'}"
        return f"Your final score: {result['scores']['player']}"
    
    def get_game_state(self):
        return {
            'game_type': self.game_type,
            'mode': self.mode,
            'is_active': self.is_active,
            'current_turn': self.current_turn,
            'players': {
                'player1': {'score': self.players['player1']['score']},
                'player2': {'score': self.players['player2']['score']} if self.players['player2'] else None
            }
        }
    
    def reset_game(self):
        self.players = {}
        self.is_active = False