import random
from games.base_game import BaseGame

class BasketballGame(BaseGame):
    def __init__(self):
        super().__init__()
        self.game_type = 'basketball'
        self.max_attempts = 5
        self.distances = [2, 3, 4, 5, 6]
    
    def start_game(self, player1_id, player2_id=None):
        self.players = {
            'player1': {'id': player1_id, 'score': 0, 'attempts': 0, 'made': 0},
            'player2': {'id': player2_id, 'score': 0, 'attempts': 0, 'made': 0} if player2_id else None
        }
        self.current_turn = 'player1'
        self.is_active = True
        return {'message': "🏀 Basketball! 5 shots. Use /roll"}
    
    def make_move(self, player_id, move_data):
        if not self.is_active:
            return False, {'message': 'Game over!'}
        
        current = None
        if self.players['player1']['id'] == player_id:
            current = 'player1'
        elif self.players['player2'] and self.players['player2']['id'] == player_id:
            current = 'player2'
        
        if not current or current != self.current_turn:
            return False, {'message': 'Not your turn!'}
        
        if self.players[current]['attempts'] >= self.max_attempts:
            return False, {'message': 'No attempts left!'}
        
        distance = self.distances[self.players[current]['attempts'] % len(self.distances)]
        success_rate = max(0.2, 0.9 - (distance * 0.1))
        made = random.random() < success_rate
        points = 3 if made and distance >= 5 else (2 if made else 0)
        
        self.players[current]['score'] += points
        self.players[current]['attempts'] += 1
        if made:
            self.players[current]['made'] += 1
        
        if self.players[current]['attempts'] >= self.max_attempts:
            self.is_active = False
            result = self.get_result()
            return True, {'message': f"🏀 Game Over!\n{self._format_result(result)}", 'result': result}
        
        if self.mode == 'pvp':
            self.current_turn = 'player2' if current == 'player1' else 'player1'
        
        return True, {'message': f"🏀 {'BASKET! 🏆' if made else 'MISS! ❌'}\nDistance: {distance}m\nPoints: {points}\nTotal: {self.players[current]['score']}"}
    
    def get_result(self):
        if self.mode == 'pvp':
            p1 = self.players['player1']['score']
            p2 = self.players['player2']['score']
            return {'scores': {'player1': p1, 'player2': p2}, 'winner': 'player1' if p1 > p2 else 'player2' if p2 > p1 else None}
        return {'scores': {'player': self.players['player1']['score']}, 'winner': 'player'}
    
    def _format_result(self, result):
        if self.mode == 'pvp':
            return f"Player 1: {result['scores']['player1']}\nPlayer 2: {result['scores']['player2']}\n{'Winner: Player ' + result['winner'] if result['winner'] else 'Draw!'}"
        return f"Your final score: {result['scores']['player']}"
    
    def get_game_state(self):
        return {
            'game_type': self.game_type,
            'mode': self.mode,
            'is_active': self.is_active,
            'current_turn': self.current_turn,
            'players': {
                'player1': {'score': self.players['player1']['score']},
                'player2': {'score': self.players['player2']['score']} if self.players['player2'] else None
            }
        }
    
    def reset_game(self):
        self.players = {}
        self.is_active = False