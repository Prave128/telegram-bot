import random
from games.base_game import BaseGame

class MinesGame(BaseGame):
    def __init__(self):
        super().__init__()
        self.game_type = 'mines'
        self.grid_size = 5
        self.total_mines = 5
        self.grid = {}
        self.revealed = {}
    
    def start_game(self, player1_id, player2_id=None):
        total_cells = self.grid_size * self.grid_size
        mine_positions = set(random.sample(range(total_cells), self.total_mines))
        self.grid = {i: i in mine_positions for i in range(total_cells)}
        self.revealed = {i: False for i in range(total_cells)}
        
        self.players = {
            'player1': {'id': player1_id, 'score': 0, 'cells': 0},
            'player2': {'id': player2_id, 'score': 0, 'cells': 0} if player2_id else None
        }
        self.current_turn = 'player1'
        self.is_active = True
        return {'message': f"💣 Mines! {self.grid_size}x{self.grid_size} grid. Use /roll <number 1-25>"}
    
    def make_move(self, player_id, move_data):
        if not self.is_active:
            return False, {'message': 'Game over!'}
        
        current = None
        if self.players['player1']['id'] == player_id:
            current = 'player1'
        elif self.players['player2'] and self.players['player2']['id'] == player_id:
            current = 'player2'
        
        if not current or current != self.current_turn:
            return False, {'message': 'Not your turn!'}
        
        cell = move_data.get('cell')
        if cell is None:
            return False, {'message': 'Please specify cell: /roll 5'}
        
        try:
            cell_idx = int(cell) - 1
        except ValueError:
            return False, {'message': 'Invalid cell number!'}
        
        total_cells = self.grid_size * self.grid_size
        if cell_idx < 0 or cell_idx >= total_cells:
            return False, {'message': f'Cell must be 1-{total_cells}'}
        
        if self.revealed[cell_idx]:
            return False, {'message': 'Cell already revealed!'}
        
        self.revealed[cell_idx] = True
        self.players[current]['cells'] += 1
        
        if self.grid[cell_idx]:  # Mine!
            self.is_active = False
            result = self.get_result()
            return True, {'message': f"💥 BOOM! Mine hit!\n{self._format_result(result)}", 'result': result}
        
        self.players[current]['score'] += 1
        
        # Check if all safe cells revealed
        safe_revealed = sum(1 for i in range(total_cells) if self.revealed[i] and not self.grid[i])
        total_safe = total_cells - self.total_mines
        
        if safe_revealed >= total_safe:
            self.is_active = False
            result = self.get_result()
            return True, {'message': f"🎉 All safe cells found!\n{self._format_result(result)}", 'result': result}
        
        if self.mode == 'pvp':
            self.current_turn = 'player2' if current == 'player1' else 'player1'
        
        return True, {'message': f"🔍 Safe cell! +1 point\nScore: {self.players[current]['score']}"}
    
    def get_result(self):
        if self.mode == 'pvp':
            p1 = self.players['player1']['score']
            p2 = self.players['player2']['score']
            return {'scores': {'player1': p1, 'player2': p2}, 'winner': 'player1' if p1 > p2 else 'player2' if p2 > p1 else None}
        return {'scores': {'player': self.players['player1']['score']}, 'winner': 'player'}
    
    def _format_result(self, result):
        if self.mode == 'pvp':
            return f"Player 1: {result['scores']['player1']}\nPlayer 2: {result['scores']['player2']}\n{'Winner: Player ' + result['winner'] if result['winner'] else 'Draw!'}"
        return f"Your score: {result['scores']['player']}"
    
    def get_game_state(self):
        return {
            'game_type': self.game_type,
            'mode': self.mode,
            'is_active': self.is_active,
            'current_turn': self.current_turn,
            'players': {
                'player1': {'score': self.players['player1']['score']},
                'player2': {'score': self.players['player2']['score']} if self.players['player2'] else None
            }
        }
    
    def reset_game(self):
        self.players = {}
        self.is_active = False