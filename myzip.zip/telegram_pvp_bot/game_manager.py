# game_manager.py
from typing import Dict, Optional, List
import uuid
from datetime import datetime, timedelta
from games.dice import DiceGame
from games.bowling import BowlingGame
from games.base_game import BaseGame

# Game settings
PLATFORM_COMMISSION_PERCENT = 15
WINNER_GETS_PERCENT = 85

class GameManager:
    def __init__(self):
        self.active_games = {}
        self.game_classes = {
            'dice': DiceGame,
            'bowling': BowlingGame,
        }
        self.user_games = {}
        self.game_timeouts = {}
        self.pending_challenges = {}
    
    def create_game(self, game_type: str, mode: str, player1_id: int, 
                    player2_id: int = None, bet_amount: int = 0, 
                    rolls: int = 3, rounds_type: str = "3r1w", 
                    currency: str = 'INR') -> Dict:
        """Create a new game with optional betting and roll count"""
        if game_type not in self.game_classes:
            return {'error': 'Invalid game type'}
        
        if player1_id in self.user_games:
            return {'error': 'You are already in a game! Finish it first.'}
        
        if player2_id and player2_id in self.user_games:
            return {'error': 'Player 2 is already in a game!'}
        
        game = self.game_classes[game_type]()
        game.game_id = str(uuid.uuid4())[:8]
        game.mode = mode
        game.currency = currency
        
        # Setup game with rounds and bet
        if game_type == 'dice':
            game.setup_game(rounds_type, rolls, bet_amount, currency)
        
        if mode == 'pvp' and bet_amount > 0:
            game.bet_amount = bet_amount
            game.platform_fee = int(bet_amount * PLATFORM_COMMISSION_PERCENT / 100)
            game.prize_pool = bet_amount - game.platform_fee
        else:
            game.bet_amount = 0
            game.platform_fee = 0
            game.prize_pool = 0
        
        if mode == 'pvp':
            if not player2_id:
                return {'error': 'Player 2 required for PVP mode'}
            result = game.start_game(player1_id, player2_id)
        elif mode == 'bot':
            result = game.start_game(player1_id, -1)
        else:
            result = game.start_game(player1_id)
        
        self.active_games[game.game_id] = game
        self.user_games[player1_id] = game.game_id
        if player2_id:
            self.user_games[player2_id] = game.game_id
        
        self.game_timeouts[game.game_id] = datetime.utcnow() + timedelta(minutes=10)
        
        return {
            'game_id': game.game_id,
            'message': result['message'],
            'game_state': result['game_state'],
            'bet_amount': game.bet_amount,
            'platform_fee': game.platform_fee,
            'prize_pool': game.prize_pool,
            'max_rolls': game.max_rolls if game_type == 'dice' else None,
            'rounds_type': game.rounds_type if game_type == 'dice' else None,
            'currency': game.currency
        }
    
    def create_challenge(self, game_type: str, challenger_id: int, 
                         challenged_id: int, bet_amount: int, 
                         rounds_type: str = "3r1w", rolls: int = 3,
                         currency: str = 'INR') -> Dict:
        """Create a challenge with bet amount and roll count"""
        challenge_id = str(uuid.uuid4())[:8]
        
        self.pending_challenges[challenge_id] = {
            'game_type': game_type,
            'challenger_id': challenger_id,
            'challenged_id': challenged_id,
            'bet_amount': bet_amount,
            'rounds_type': rounds_type,
            'rolls': rolls,
            'currency': currency,
            'status': 'pending',
            'created_at': datetime.utcnow()
        }
        
        symbol = '₹' if currency == 'INR' else '$'
        return {
            'challenge_id': challenge_id,
            'message': f"💰 Challenge Created!\n"
                      f"Game: {game_type.upper()}\n"
                      f"Bet: {symbol}{bet_amount}\n"
                      f"Rounds: {rounds_type.upper()}\n"
                      f"Rolls: {rolls} each\n"
                      f"Waiting for opponent to accept..."
        }
    
    def accept_challenge(self, challenge_id: str, player_id: int) -> Dict:
        """Accept a PVP challenge"""
        if challenge_id not in self.pending_challenges:
            return {'error': 'Challenge not found'}
        
        challenge = self.pending_challenges[challenge_id]
        
        if challenge['status'] != 'pending':
            return {'error': 'Challenge already handled'}
        
        if challenge['challenged_id'] != player_id:
            return {'error': 'You are not the challenged player'}
        
        # Create the game
        result = self.create_game(
            challenge['game_type'],
            'pvp',
            challenge['challenger_id'],
            challenge['challenged_id'],
            challenge['bet_amount'],
            challenge.get('rolls', 3),
            challenge.get('rounds_type', '3r1w'),
            challenge.get('currency', 'INR')
        )
        
        if 'error' in result:
            return result
        
        # Set usernames in game
        game = self.active_games.get(result['game_id'])
        if game:
            from database import get_user_profile
            p1 = get_user_profile(challenge['challenger_id'])
            p2 = get_user_profile(challenge['challenged_id'])
            game.player1_username = p1['username'] if p1 else f"Player{challenge['challenger_id']}"
            game.player2_username = p2['username'] if p2 else f"Player{challenge['challenged_id']}"
        
        # Mark challenge as accepted
        challenge['status'] = 'accepted'
        del self.pending_challenges[challenge_id]
        
        return result
    
    def decline_challenge(self, challenge_id: str, player_id: int) -> Dict:
        """Decline a PVP challenge"""
        if challenge_id not in self.pending_challenges:
            return {'error': 'Challenge not found'}
        
        challenge = self.pending_challenges[challenge_id]
        
        if challenge['challenged_id'] != player_id:
            return {'error': 'You are not the challenged player'}
        
        challenge['status'] = 'declined'
        del self.pending_challenges[challenge_id]
        
        return {
            'message': f"❌ Challenge declined"
        }
    
    def get_pending_challenge(self, challenge_id: str) -> Optional[Dict]:
        return self.pending_challenges.get(challenge_id)
    
    def get_user_pending_challenge(self, user_id: int) -> Optional[Dict]:
        """Get pending challenge for a user"""
        for challenge in self.pending_challenges.values():
            if challenge.get('challenged_id') == user_id and challenge.get('status') == 'pending':
                return challenge
        return None
    
    def make_move(self, game_id: str, player_id: int, move_data: Dict = None) -> Dict:
        if game_id not in self.active_games:
            return {'error': 'Game not found'}
        
        game = self.active_games[game_id]
        
        if datetime.utcnow() > self.game_timeouts[game_id]:
            self.end_game(game_id)
            return {'error': 'Game timed out!'}
        
        success, result = game.make_move(player_id, move_data)
        
        if not success:
            return {'error': result['message']}
        
        self.game_timeouts[game_id] = datetime.utcnow() + timedelta(minutes=5)
        
        # If game has result, handle end game
        if result.get('result'):
            self._handle_game_end(game_id, result['result'])
        
        return {
            'message': result['message'],
            'game_state': result.get('game_state'),
            'result': result.get('result')
        }
    
    def _handle_game_end(self, game_id: str, result: Dict):
        """Handle game end - update wallets and stats"""
        game = self.active_games.get(game_id)
        if not game:
            return
        
        from database import get_user_currency, get_user_balance, update_wallet, update_user_stats, add_transaction
        
        if game.mode == 'pvp':
            winner_id = result.get('winner_id')
            loser_id = result.get('loser_id')
            bet_amount = game.bet_amount
            currency = game.currency
            
            if winner_id and loser_id:
                # Winner gets prize pool
                prize_pool = game.prize_pool
                prize_in_paise = prize_pool * 100
                
                # Update winner wallet
                update_wallet(winner_id, prize_in_paise, currency)
                update_user_stats(winner_id, won=True)
                
                # Update loser stats
                update_user_stats(loser_id, won=False)
                
                # Add transactions
                balance = get_user_balance(winner_id, currency)
                add_transaction(winner_id, 'pvp_win', prize_in_paise, currency, balance, 
                              f"PVP Dice win - {game.rounds_type}")
                
                # Platform fee transaction (admin gets this)
                platform_fee = game.platform_fee * 100
                # Note: Admin wallet would need to be updated separately
                
            elif result.get('is_draw'):
                # Draw - refund both players
                bet_in_paise = bet_amount * 100
                p1_id = game.players['player1']['id']
                p2_id = game.players['player2']['id']
                
                update_wallet(p1_id, bet_in_paise, currency)
                update_wallet(p2_id, bet_in_paise, currency)
                
                update_user_stats(p1_id, draw=True)
                update_user_stats(p2_id, draw=True)
        
        self.end_game(game_id)
    
    def end_game(self, game_id: str):
        if game_id in self.active_games:
            game = self.active_games[game_id]
            game.reset_game()
            
            for user_id, gid in list(self.user_games.items()):
                if gid == game_id:
                    del self.user_games[user_id]
            
            del self.active_games[game_id]
            if game_id in self.game_timeouts:
                del self.game_timeouts[game_id]
    
    def get_game(self, game_id: str) -> Optional[BaseGame]:
        return self.active_games.get(game_id)
    
    def get_user_game(self, user_id: int) -> Optional[str]:
        return self.user_games.get(user_id)
    
    def get_pvp_history(self, user_id: int, limit: int = 20) -> List[Dict]:
        """Get PVP game history for a user"""
        import sqlite3
        import json
        from config import DB_PATH
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''
            SELECT * FROM game_history 
            WHERE (player1_id = ? OR player2_id = ?) AND mode = 'pvp'
            ORDER BY created_at DESC LIMIT ?
        ''', (user_id, user_id, limit))
        games = c.fetchall()
        conn.close()
        
        if not games:
            return []
        
        history = []
        for game in games:
            history.append({
                'game_id': game[1] if len(game) > 1 else '',
                'game_type': game[2] if len(game) > 2 else 'dice',
                'mode': game[3] if len(game) > 3 else 'pvp',
                'rounds_type': game[4] if len(game) > 4 else '',
                'player1_id': game[5] if len(game) > 5 else 0,
                'player2_id': game[6] if len(game) > 6 else 0,
                'winner_id': game[7] if len(game) > 7 else 0,
                'bet_amount': game[8] if len(game) > 8 else 0,
                'currency': game[9] if len(game) > 9 else 'INR',
                'platform_fee': game[10] if len(game) > 10 else 0,
                'winner_amount': game[11] if len(game) > 11 else 0,
                'player1_rolls': json.loads(game[12]) if len(game) > 12 and game[12] else [],
                'player2_rolls': json.loads(game[13]) if len(game) > 13 and game[13] else [],
                'player1_total': game[14] if len(game) > 14 else 0,
                'player2_total': game[15] if len(game) > 15 else 0,
                'created_at': game[17] if len(game) > 17 else None
            })
        
        return history