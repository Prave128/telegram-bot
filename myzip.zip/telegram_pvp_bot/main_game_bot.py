import logging
from typing import Dict, Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters
)
from telegram.request import HTTPXRequest
from datetime import datetime, timedelta
import sqlite3
import random
import string
import asyncio
import os

# ============ CONFIGURATION ============

BOT_TOKEN = "8819667974:AAFfXGJ3Pnb8Bh9HqV7gtO3vRM5Jd6cr1yM"
BOT_USERNAME = "CasinoPayment26_bot"

# Brand Name
BRAND_NAME = "🎰 CASINO INDIA"
BRAND_EMOJI = "🎰"

# Admin
ADMIN_USER_ID = 5943318266
ADMIN_USERNAME = "@XTOP_879"

# Payment Bot Link
PAYMENT_BOT_LINK = "https://t.me/CasinoIndia2026_bot"

# IMPORTANT: Use the SAME database as payment bot
DB_PATH = "payment_bot.db"  # Shared database

# Game Settings
WINNER_GETS_PERCENT = 85  # Winner gets 85%
PLATFORM_FEE_PERCENT = 15  # Platform fee 15% (Hidden from users)

# PVP Bet Amounts
INR_BET_AMOUNTS = [10, 20, 30, 40, 50, 100, 200]
USD_BET_AMOUNTS = [1, 2, 3, 4, 10]

# PVP Rounds Options
ROUNDS_OPTIONS = [
    {"key": "2r1w", "label": "2 Rolls 1 Win", "rolls": 2},
    {"key": "3r1w", "label": "3 Rolls 1 Win", "rolls": 3},
    {"key": "4r1w", "label": "4 Rolls 1 Win", "rolls": 4},
    {"key": "5r1w", "label": "5 Rolls 1 Win", "rolls": 5},
]

# Dice emojis
DICE_EMOJIS = {
    1: "⚀",
    2: "⚁", 
    3: "⚂",
    4: "⚃",
    5: "⚄",
    6: "⚅"
}

# Challenge timeout (seconds)
CHALLENGE_TIMEOUT = 120  # 2 minutes

# ============ HELPER FUNCTIONS ============

def get_brand_header():
    return f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  🎰 CASINO INDIA  🎰              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
"""

def format_currency(amount, currency='INR'):
    symbol = '₹' if currency == 'INR' else '$'
    return f"{symbol}{amount/100:.2f}"

def get_dice_display(rolls):
    if not rolls:
        return ""
    return ' '.join([f"{DICE_EMOJIS.get(r, '🎲')}" for r in rolls])

# ============ DATABASE ============

def get_db():
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = get_db()
    c = conn.cursor()
    
    c.execute("PRAGMA table_info(users)")
    columns = [col[1] for col in c.fetchall()]
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            currency TEXT DEFAULT 'INR',
            wallet_balance_inr INTEGER DEFAULT 0,
            wallet_balance_usd INTEGER DEFAULT 0,
            total_games INTEGER DEFAULT 0,
            total_wins INTEGER DEFAULT 0,
            total_losses INTEGER DEFAULT 0,
            total_draws INTEGER DEFAULT 0,
            win_streak INTEGER DEFAULT 0,
            max_win_streak INTEGER DEFAULT 0,
            rating INTEGER DEFAULT 0,
            level INTEGER DEFAULT 1,
            experience INTEGER DEFAULT 0,
            referral_code TEXT,
            daily_bonus_claimed TIMESTAMP,
            daily_bonus_streak INTEGER DEFAULT 0,
            total_deposited_inr INTEGER DEFAULT 0,
            total_deposited_usd INTEGER DEFAULT 0,
            total_withdrawn_inr INTEGER DEFAULT 0,
            total_withdrawn_usd INTEGER DEFAULT 0,
            total_won_inr INTEGER DEFAULT 0,
            total_won_usd INTEGER DEFAULT 0,
            total_lost_inr INTEGER DEFAULT 0,
            total_lost_usd INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    new_columns = ['win_streak', 'max_win_streak', 'total_lost_inr', 'total_lost_usd']
    for col in new_columns:
        if col not in columns:
            try:
                c.execute(f'ALTER TABLE users ADD COLUMN {col} INTEGER DEFAULT 0')
            except sqlite3.OperationalError:
                pass
    
    if 'daily_bonus_claimed' not in columns:
        try:
            c.execute('ALTER TABLE users ADD COLUMN daily_bonus_claimed TIMESTAMP')
        except sqlite3.OperationalError:
            pass
    
    if 'daily_bonus_streak' not in columns:
        try:
            c.execute('ALTER TABLE users ADD COLUMN daily_bonus_streak INTEGER DEFAULT 0')
        except sqlite3.OperationalError:
            pass
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS game_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            game_id TEXT,
            game_type TEXT,
            mode TEXT,
            rounds_type TEXT,
            player1_id INTEGER,
            player2_id INTEGER,
            winner_id INTEGER,
            bet_amount INTEGER,
            currency TEXT,
            platform_fee INTEGER,
            commission_fee INTEGER,
            winner_amount INTEGER,
            player1_rolls TEXT,
            player2_rolls TEXT,
            player1_total INTEGER,
            player2_total INTEGER,
            status TEXT DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

# ============ USER FUNCTIONS ============

def get_or_create_user(user_id, username, first_name, last_name=None):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = c.fetchone()
    
    if not user:
        referral_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        username = username if username else f"user_{user_id}"
        first_name = first_name if first_name else "User"
        last_name = last_name if last_name else ""
        
        c.execute('''
            INSERT INTO users (user_id, username, first_name, last_name, referral_code, wallet_balance_inr, wallet_balance_usd)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, username, first_name, last_name, referral_code, 0, 0))
        conn.commit()
    
    conn.close()

def get_user_profile(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = c.fetchone()
    conn.close()
    
    if user:
        return {
            'user_id': user[0],
            'username': user[1] or f"User{user[0]}",
            'first_name': user[2] or "User",
            'last_name': user[3] or "",
            'currency': user[4] or 'INR',
            'wallet_balance_inr': user[5] or 0,
            'wallet_balance_usd': user[6] or 0,
            'total_games': user[7] or 0,
            'total_wins': user[8] or 0,
            'total_losses': user[9] or 0,
            'total_draws': user[10] or 0,
            'win_streak': user[11] if len(user) > 11 else 0,
            'max_win_streak': user[12] if len(user) > 12 else 0,
            'rating': user[13] if len(user) > 13 else 0,
            'level': user[14] if len(user) > 14 else 1,
            'experience': user[15] if len(user) > 15 else 0,
            'referral_code': user[16] if len(user) > 16 else '',
            'daily_bonus_claimed': user[17] if len(user) > 17 else None,
            'daily_bonus_streak': user[18] if len(user) > 18 else 0,
            'total_deposited_inr': user[19] if len(user) > 19 else 0,
            'total_deposited_usd': user[20] if len(user) > 20 else 0,
            'total_withdrawn_inr': user[21] if len(user) > 21 else 0,
            'total_withdrawn_usd': user[22] if len(user) > 22 else 0,
            'total_won_inr': user[23] if len(user) > 23 else 0,
            'total_won_usd': user[24] if len(user) > 24 else 0,
            'total_lost_inr': user[25] if len(user) > 25 else 0,
            'total_lost_usd': user[26] if len(user) > 26 else 0,
            'created_at': user[27] if len(user) > 27 else None
        }
    return None

def get_user_currency(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT currency FROM users WHERE user_id = ?', (user_id,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else 'INR'

def set_user_currency(user_id, currency):
    conn = get_db()
    c = conn.cursor()
    c.execute('UPDATE users SET currency = ? WHERE user_id = ?', (currency, user_id))
    conn.commit()
    conn.close()

def get_user_balance(user_id, currency='INR'):
    conn = get_db()
    c = conn.cursor()
    if currency == 'INR':
        c.execute('SELECT wallet_balance_inr FROM users WHERE user_id = ?', (user_id,))
    else:
        c.execute('SELECT wallet_balance_usd FROM users WHERE user_id = ?', (user_id,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else 0

def update_wallet(user_id, amount, currency='INR'):
    conn = get_db()
    c = conn.cursor()
    if currency == 'INR':
        c.execute('UPDATE users SET wallet_balance_inr = wallet_balance_inr + ? WHERE user_id = ?', (amount, user_id))
    else:
        c.execute('UPDATE users SET wallet_balance_usd = wallet_balance_usd + ? WHERE user_id = ?', (amount, user_id))
    conn.commit()
    conn.close()

def update_user_stats(user_id, won=None, draw=False, bet_amount=0, currency='INR'):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT total_games, total_wins, total_losses, total_draws, win_streak, max_win_streak, rating, experience, level FROM users WHERE user_id = ?', (user_id,))
    user = c.fetchone()
    
    if user:
        total_games, total_wins, total_losses, total_draws, win_streak, max_win_streak, rating, experience, level = user
        total_games += 1
        
        if draw:
            total_draws += 1
            win_streak = 0
        elif won is True:
            total_wins += 1
            win_streak += 1
            if win_streak > max_win_streak:
                max_win_streak = win_streak
            rating += 10
            experience += 25
            
            if currency == 'INR':
                c.execute('UPDATE users SET total_won_inr = total_won_inr + ? WHERE user_id = ?', (bet_amount * 100, user_id))
            else:
                c.execute('UPDATE users SET total_won_usd = total_won_usd + ? WHERE user_id = ?', (bet_amount * 100, user_id))
        elif won is False:
            total_losses += 1
            win_streak = 0
            rating -= 5
            experience += 5
            
            if currency == 'INR':
                c.execute('UPDATE users SET total_lost_inr = total_lost_inr + ? WHERE user_id = ?', (bet_amount * 100, user_id))
            else:
                c.execute('UPDATE users SET total_lost_usd = total_lost_usd + ? WHERE user_id = ?', (bet_amount * 100, user_id))
        
        if rating < 0:
            rating = 0
        
        # Level up: 0-100 experience per level
        if experience >= 100:
            level += 1
            experience = 0
        
        c.execute('''
            UPDATE users SET 
                total_games = ?, total_wins = ?, total_losses = ?, total_draws = ?,
                win_streak = ?, max_win_streak = ?,
                rating = ?, experience = ?, level = ?
            WHERE user_id = ?
        ''', (total_games, total_wins, total_losses, total_draws, win_streak, max_win_streak, rating, experience, level, user_id))
        conn.commit()
    
    conn.close()

def add_transaction(user_id, type, amount, currency, balance_after, description):
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        INSERT INTO transactions (user_id, type, amount, currency, balance_after, description)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (user_id, type, amount, currency, balance_after, description))
    conn.commit()
    conn.close()

def save_game_history(game_data):
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        INSERT INTO game_history 
        (game_id, game_type, mode, rounds_type, player1_id, player2_id, winner_id, 
         bet_amount, currency, platform_fee, commission_fee, winner_amount, 
         player1_rolls, player2_rolls, player1_total, player2_total)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        game_data.get('game_id'),
        game_data.get('game_type', 'dice'),
        'pvp',
        game_data.get('rounds_type'),
        game_data.get('player1_id'),
        game_data.get('player2_id'),
        game_data.get('winner_id'),
        game_data.get('bet_amount', 0),
        game_data.get('currency', 'INR'),
        game_data.get('platform_fee', 0),
        game_data.get('commission_fee', 0),
        game_data.get('winner_amount', 0),
        game_data.get('player1_rolls', '[]'),
        game_data.get('player2_rolls', '[]'),
        game_data.get('player1_total', 0),
        game_data.get('player2_total', 0)
    ))
    conn.commit()
    conn.close()

def get_game_history(user_id, limit=10, offset=0):
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        SELECT * FROM game_history 
        WHERE (player1_id = ? OR player2_id = ?) AND mode = 'pvp'
        ORDER BY created_at DESC LIMIT ? OFFSET ?
    ''', (user_id, user_id, limit, offset))
    games = c.fetchall()
    conn.close()
    return games

def get_total_history_count(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        SELECT COUNT(*) FROM game_history 
        WHERE (player1_id = ? OR player2_id = ?) AND mode = 'pvp'
    ''', (user_id, user_id))
    count = c.fetchone()[0]
    conn.close()
    return count

# ============ TOP PLAYERS FUNCTIONS ============

def get_top_players(period='all', limit=10):
    """Get top players by net profit"""
    conn = get_db()
    c = conn.cursor()
    
    if period == 'daily':
        date_filter = "WHERE date(created_at) = date('now')"
    elif period == 'weekly':
        date_filter = "WHERE date(created_at) >= date('now', '-7 days')"
    elif period == 'monthly':
        date_filter = "WHERE date(created_at) >= date('now', '-30 days')"
    else:
        date_filter = ""
    
    # Get top players by total winnings - losses
    query = f'''
        SELECT 
            u.user_id, 
            u.username, 
            u.first_name,
            u.currency,
            u.wallet_balance_inr,
            u.wallet_balance_usd,
            u.total_games,
            u.total_wins,
            (u.total_won_inr + u.total_won_usd * 83) - (u.total_lost_inr + u.total_lost_usd * 83) as net_profit_inr
        FROM users u
        WHERE u.total_games > 0
        ORDER BY net_profit_inr DESC
        LIMIT ?
    '''
    
    c.execute(query, (limit,))
    users = c.fetchall()
    conn.close()
    
    return users

# ============ DAILY BONUS FUNCTIONS ============

def db_claim_daily_bonus(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT daily_bonus_claimed, daily_bonus_streak FROM users WHERE user_id = ?', (user_id,))
    result = c.fetchone()
    
    if not result:
        conn.close()
        return False, "User not found"
    
    streak = result[1] or 0
    
    if result[0]:
        try:
            last_claim = datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
            if (datetime.now() - last_claim).days < 1:
                conn.close()
                return False, f"Already claimed today! Streak: {streak} days"
            
            if (datetime.now() - last_claim).days == 1:
                streak += 1
            else:
                streak = 1
        except:
            streak = 1
    else:
        streak = 1
    
    currency = get_user_currency(user_id)
    
    if streak >= 10:
        bonus = 1500
        bonus_msg = "₹15 (10 Days Streak!) 🎉"
    elif streak >= 3:
        bonus = 1000
        bonus_msg = "₹10 (3 Days Streak!) 🎉"
    else:
        bonus = 0
        bonus_msg = f"Need {3 - streak} more days for ₹10"
    
    if bonus > 0:
        if currency == 'USD':
            bonus = int(bonus / 83)
        
        update_wallet(user_id, bonus, currency)
        
        symbol = '₹' if currency == 'INR' else '$'
        bonus_display = f"{symbol}{bonus/100:.2f}"
    else:
        bonus_display = "₹0"
    
    balance = get_user_balance(user_id, currency)
    add_transaction(user_id, 'daily_bonus', bonus, currency, balance, f"Daily bonus - Day {streak}")
    
    c.execute('''
        UPDATE users SET 
            daily_bonus_claimed = CURRENT_TIMESTAMP,
            daily_bonus_streak = ?
        WHERE user_id = ?
    ''', (streak, user_id))
    conn.commit()
    conn.close()
    
    return True, f"Day {streak}! {bonus_display} earned!\n{bonus_msg}"

def get_daily_bonus_info(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT daily_bonus_claimed, daily_bonus_streak FROM users WHERE user_id = ?', (user_id,))
    result = c.fetchone()
    conn.close()
    
    if not result or not result[0]:
        return {'can_claim': True, 'streak': 0, 'next': 'Day 1/3 - ₹10 goal'}
    
    try:
        last_claim = datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
        streak = result[1] or 0
        
        if (datetime.now() - last_claim).days < 1:
            return {'can_claim': False, 'streak': streak, 'next': f'Day {streak+1}/3 - ₹10 goal'}
        
        return {'can_claim': True, 'streak': streak, 'next': f'Day {streak+1}/3 - ₹10 goal'}
    except:
        return {'can_claim': True, 'streak': 0, 'next': 'Day 1/3 - ₹10 goal'}

# ============ PVP GAME HANDLER ============

class PVPGameHandler:
    def __init__(self):
        self.active_pvp_games = {}
        self.game_buttons = {}
    
    def create_pvp_game(self, game_id, challenger_id, challenged_id, rounds_type, rolls, bet_amount, currency):
        self.active_pvp_games[game_id] = {
            'game_id': game_id,
            'challenger_id': challenger_id,
            'challenged_id': challenged_id,
            'rounds_type': rounds_type,
            'total_rolls': rolls,
            'bet_amount': bet_amount,
            'currency': currency,
            'current_turn': challenger_id,
            'player1_rolls': [],
            'player2_rolls': [],
            'player1_total': 0,
            'player2_total': 0,
            'player1_roll_count': 0,
            'player2_roll_count': 0,
            'is_active': True,
            'game_over': False,
            'result_sent': False,
            'challenger_name': '',
            'challenged_name': '',
            'roll_in_progress': False,
            'group_chat_id': None,
            'message_id': None
        }
        
        self.game_buttons[game_id] = {
            'allowed_user': challenger_id,
            'challenger_id': challenger_id,
            'challenged_id': challenged_id
        }
        
        logging.info(f"PVP Game Created: {game_id}")
        return self.active_pvp_games[game_id]
    
    def get_game(self, game_id):
        return self.active_pvp_games.get(game_id)
    
    def get_user_game(self, user_id):
        for game_id, game in self.active_pvp_games.items():
            if (game['challenger_id'] == user_id or game['challenged_id'] == user_id):
                return game
        return None
    
    def get_other_player(self, game, user_id):
        if game['challenger_id'] == user_id:
            return game['challenged_id']
        return game['challenger_id']
    
    def get_current_player_name(self, game):
        if game['current_turn'] == game['challenger_id']:
            return game.get('challenger_name', 'Player 1')
        return game.get('challenged_name', 'Player 2')
    
    def is_allowed_to_roll(self, game_id, user_id):
        if game_id not in self.game_buttons:
            return False
        return self.game_buttons[game_id]['allowed_user'] == user_id
    
    def set_next_player(self, game_id, next_user_id):
        if game_id in self.game_buttons:
            self.game_buttons[game_id]['allowed_user'] = next_user_id
    
    async def send_telegram_dice(self, bot, chat_id):
        try:
            message = await bot.send_dice(chat_id=chat_id, emoji="🎲")
            return message.dice.value
        except Exception as e:
            logging.error(f"Error sending dice: {e}")
            return random.randint(1, 6)
    
    async def make_roll(self, game_id, user_id, bot, chat_id) -> Dict:
        game = self.active_pvp_games.get(game_id)
        if not game:
            return {'error': 'Game not found!'}
        
        if not game['is_active']:
            return {'error': 'Game is already over!'}
        
        if game['game_over']:
            return {'error': 'Game has ended!'}
        
        if not self.is_allowed_to_roll(game_id, user_id):
            return {'error': f"Not your turn! Only {self.get_current_player_name(game)} can roll."}
        
        if game['current_turn'] != user_id:
            return {'error': f"Not your turn! Only {self.get_current_player_name(game)} can roll."}
        
        if game.get('roll_in_progress', False):
            return {'error': 'Roll in progress! Please wait.'}
        
        game['roll_in_progress'] = True
        
        roll_value = await self.send_telegram_dice(bot, chat_id)
        
        if user_id == game['challenger_id']:
            if game['player1_roll_count'] >= game['total_rolls']:
                game['roll_in_progress'] = False
                return {'error': 'You have completed all your rolls!'}
            game['player1_rolls'].append(roll_value)
            game['player1_total'] += roll_value
            game['player1_roll_count'] += 1
            player_name = game.get('challenger_name', 'Player 1')
        else:
            if game['player2_roll_count'] >= game['total_rolls']:
                game['roll_in_progress'] = False
                return {'error': 'You have completed all your rolls!'}
            game['player2_rolls'].append(roll_value)
            game['player2_total'] += roll_value
            game['player2_roll_count'] += 1
            player_name = game.get('challenged_name', 'Player 2')
        
        player_completed = False
        if user_id == game['challenger_id']:
            if game['player1_roll_count'] >= game['total_rolls']:
                player_completed = True
        else:
            if game['player2_roll_count'] >= game['total_rolls']:
                player_completed = True
        
        dice_emoji = DICE_EMOJIS.get(roll_value, '🎲')
        rolls_so_far = game['player1_rolls'] if user_id == game['challenger_id'] else game['player2_rolls']
        roll_history = ' '.join([f"{DICE_EMOJIS.get(r, '🎲')}" for r in rolls_so_far])
        roll_numbers = f"({', '.join(map(str, rolls_so_far))})"
        total_score = game['player1_total'] if user_id == game['challenger_id'] else game['player2_total']
        
        message = f"🎲 **{player_name} rolled:** {dice_emoji} **{roll_value}**\n\n"
        message += f"📊 **Your rolls:** {roll_history} {roll_numbers}\n"
        message += f"📈 **Total so far:** **{total_score}**\n"
        
        if player_completed:
            message += f"\n✅ **You completed all {game['total_rolls']} rolls!**"
            other_id = self.get_other_player(game, user_id)
            other_rolls = game['player2_roll_count'] if user_id == game['challenger_id'] else game['player1_roll_count']
            
            if other_rolls < game['total_rolls']:
                game['current_turn'] = other_id
                other_name = game.get('challenged_name', 'Player 2') if user_id == game['challenger_id'] else game.get('challenger_name', 'Player 1')
                message += f"\n\n🔄 Now it's **{other_name}'s turn** to roll!"
                game['roll_in_progress'] = False
                
                self.set_next_player(game_id, other_id)
                
                result = {
                    'success': True,
                    'message': message,
                    'roll_value': roll_value,
                    'player_completed': True,
                    'total': total_score,
                    'all_rolls': rolls_so_far,
                    'game_over': False,
                    'switch_turn': True,
                    'next_player_id': other_id,
                    'next_player_name': other_name
                }
            else:
                game['game_over'] = True
                game['is_active'] = False
                game['roll_in_progress'] = False
                result_data = self.get_result(game)
                message += f"\n\n🏆 **GAME OVER!**\n\n"
                message += self.format_result(game, result_data)
                result = {
                    'success': True,
                    'message': message,
                    'roll_value': roll_value,
                    'player_completed': True,
                    'total': total_score,
                    'all_rolls': rolls_so_far,
                    'game_over': True,
                    'result': result_data
                }
        else:
            rolls_left = game['total_rolls'] - (game['player1_roll_count'] if user_id == game['challenger_id'] else game['player2_roll_count'])
            message += f"\n⚡ Rolls left: {rolls_left}"
            game['roll_in_progress'] = False
            result = {
                'success': True,
                'message': message,
                'roll_value': roll_value,
                'player_completed': False,
                'total': total_score,
                'all_rolls': rolls_so_far,
                'game_over': False
            }
        
        return result
    
    def get_result(self, game):
        p1_total = game['player1_total']
        p2_total = game['player2_total']
        p1_rolls = game['player1_rolls']
        p2_rolls = game['player2_rolls']
        bet_amount = game['bet_amount']
        
        # Total pot = bet_amount * 2 (both players)
        total_pot = bet_amount * 2
        
        # Calculate fees correctly - 15% platform fee (hidden)
        platform_fee = int(total_pot * PLATFORM_FEE_PERCENT / 100)
        winner_amount = total_pot - platform_fee
        
        if p1_total > p2_total:
            return {
                'winner': 'player1',
                'winner_id': game['challenger_id'],
                'loser_id': game['challenged_id'],
                'winner_name': game.get('challenger_name', 'Player 1'),
                'loser_name': game.get('challenged_name', 'Player 2'),
                'player1_total': p1_total,
                'player2_total': p2_total,
                'player1_rolls': p1_rolls,
                'player2_rolls': p2_rolls,
                'bet_amount': bet_amount,
                'total_pot': total_pot,
                'platform_fee': platform_fee,
                'winner_amount': winner_amount,
                'currency': game['currency']
            }
        elif p2_total > p1_total:
            return {
                'winner': 'player2',
                'winner_id': game['challenged_id'],
                'loser_id': game['challenger_id'],
                'winner_name': game.get('challenged_name', 'Player 2'),
                'loser_name': game.get('challenger_name', 'Player 1'),
                'player1_total': p1_total,
                'player2_total': p2_total,
                'player1_rolls': p1_rolls,
                'player2_rolls': p2_rolls,
                'bet_amount': bet_amount,
                'total_pot': total_pot,
                'platform_fee': platform_fee,
                'winner_amount': winner_amount,
                'currency': game['currency']
            }
        else:
            return {
                'winner': None,
                'winner_id': None,
                'loser_id': None,
                'winner_name': None,
                'loser_name': None,
                'player1_total': p1_total,
                'player2_total': p2_total,
                'player1_rolls': p1_rolls,
                'player2_rolls': p2_rolls,
                'bet_amount': bet_amount,
                'total_pot': total_pot,
                'currency': game['currency'],
                'is_draw': True
            }
    
    def format_result(self, game, result):
        symbol = '₹' if game['currency'] == 'INR' else '$'
        p1_name = game.get('challenger_name', 'Player 1')
        p2_name = game.get('challenged_name', 'Player 2')
        
        p1_rolls_str = ' '.join([f"{DICE_EMOJIS.get(r, '🎲')}" for r in result['player1_rolls']])
        p1_rolls_num = f"({', '.join(map(str, result['player1_rolls']))})"
        p2_rolls_str = ' '.join([f"{DICE_EMOJIS.get(r, '🎲')}" for r in result['player2_rolls']])
        p2_rolls_num = f"({', '.join(map(str, result['player2_rolls']))})"
        
        message = f"📊 **Final Scores:**\n\n"
        message += f"👤 {p1_name}: **{result['player1_total']}**\n"
        message += f"   {p1_rolls_str} {p1_rolls_num}\n\n"
        message += f"👤 {p2_name}: **{result['player2_total']}**\n"
        message += f"   {p2_rolls_str} {p2_rolls_num}\n\n"
        
        if result.get('winner'):
            winner_name = result['winner_name'] or (p1_name if result['winner'] == 'player1' else p2_name)
            loser_name = result['loser_name'] or (p2_name if result['winner'] == 'player1' else p1_name)
            message += f"🎉 **{winner_name} WINS!** 🎉\n\n"
            message += f"💰 **Each Player Bet:** {symbol}{result['bet_amount']}\n"
            message += f"💰 **Total Pot:** {symbol}{result['total_pot']}\n"
            message += f"🏆 **Winner Gets:** {symbol}{result['winner_amount']}\n"
            message += f"📌 {loser_name} gets: {symbol}0"
        else:
            message += "🤝 **DRAW!**\n"
            message += f"💰 Both players get their money back!"
        
        return message
    
    def end_game(self, game_id):
        if game_id in self.active_pvp_games:
            self.active_pvp_games[game_id]['is_active'] = False
            del self.active_pvp_games[game_id]
        if game_id in self.game_buttons:
            del self.game_buttons[game_id]

pvp_handler = PVPGameHandler()

# ============ GAME MANAGER ============

class GameManager:
    def __init__(self):
        self.active_games = {}
        self.user_games = {}
        self.pending_challenges = {}
        self.challenge_players = {}
    
    def create_game(self, game_type, mode, player1_id, player2_id=None, rolls=3, 
                    bet_amount=0, rounds_type="3r1w", currency='INR'):
        if game_type == 'dice':
            game = DiceGame()
            game.setup_game(rounds_type, rolls, bet_amount, currency)
        elif game_type == 'bowling':
            game = BowlingGame()
        else:
            return {'error': 'Game not found'}
        
        game.mode = mode
        if game_type == 'dice' and bet_amount > 0:
            game.bet_amount = bet_amount
            total_pot = bet_amount * 2
            game.platform_fee = int(total_pot * PLATFORM_FEE_PERCENT / 100)
            game.prize_pool = total_pot - game.platform_fee
        
        result = game.start_game(player1_id, player2_id, rolls if game_type == 'dice' else None)
        game_id = f"{game_type}_{player1_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        self.active_games[game_id] = game
        self.user_games[player1_id] = game_id
        if player2_id:
            self.user_games[player2_id] = game_id
        return {
            'game_id': game_id, 
            'message': result['message'],
            'bet_amount': game.bet_amount,
            'platform_fee': game.platform_fee if hasattr(game, 'platform_fee') else 0,
            'prize_pool': game.prize_pool if hasattr(game, 'prize_pool') else 0,
            'rounds_type': game.rounds_type if hasattr(game, 'rounds_type') else None,
            'max_rolls': game.max_rolls if hasattr(game, 'max_rolls') else 0,
            'currency': game.currency if hasattr(game, 'currency') else 'INR'
        }
    
    def create_challenge(self, game_type, challenger_id, challenged_id, bet_amount, 
                         rounds_type="3r1w", rolls=3, currency='INR', group_chat_id=None):
        challenge_id = f"ch_{datetime.now().strftime('%Y%m%d%H%M%S')}_{random.randint(1000, 9999)}"
        
        challenger_profile = get_user_profile(challenger_id)
        challenger_username = challenger_profile['username'] if challenger_profile else str(challenger_id)
        
        challenged_profile = get_user_profile(challenged_id)
        challenged_username = challenged_profile['username'] if challenged_profile else str(challenged_id)
        
        self.pending_challenges[challenge_id] = {
            'game_type': game_type,
            'challenger_id': challenger_id,
            'challenger_username': challenger_username,
            'challenged_id': challenged_id,
            'challenged_username': challenged_username,
            'bet_amount': bet_amount,
            'rounds_type': rounds_type,
            'rolls': rolls,
            'currency': currency,
            'status': 'pending',
            'created_at': datetime.now(),
            'group_chat_id': group_chat_id
        }
        
        self.challenge_players[challenge_id] = challenged_id
        
        return {'challenge_id': challenge_id}
    
    def accept_challenge(self, challenge_id, player_id, group_chat_id=None):
        if challenge_id not in self.pending_challenges:
            return {'error': 'Challenge not found'}
        
        challenge = self.pending_challenges[challenge_id]
        if challenge['status'] != 'pending':
            return {'error': 'Challenge already handled'}
        
        if challenge['challenged_id'] != player_id:
            return {'error': 'You are not the challenged player'}
        
        result = self.create_game(
            challenge['game_type'],
            'pvp',
            challenge['challenger_id'],
            challenge['challenged_id'],
            challenge.get('rolls', 3),
            challenge.get('bet_amount', 0),
            challenge.get('rounds_type', '3r1w'),
            challenge.get('currency', 'INR')
        )
        
        if 'error' in result:
            return result
        
        p1 = get_user_profile(challenge['challenger_id'])
        p2 = get_user_profile(challenge['challenged_id'])
        
        pvp_game = pvp_handler.create_pvp_game(
            result['game_id'],
            challenge['challenger_id'],
            challenge['challenged_id'],
            challenge.get('rounds_type', '3r1w'),
            challenge.get('rolls', 3),
            challenge.get('bet_amount', 0),
            challenge.get('currency', 'INR')
        )
        
        if p1:
            pvp_game['challenger_name'] = p1['username'] or f"Player{challenge['challenger_id']}"
        else:
            pvp_game['challenger_name'] = f"Player{challenge['challenger_id']}"
        
        if p2:
            pvp_game['challenged_name'] = p2['username'] or f"Player{challenge['challenged_id']}"
        else:
            pvp_game['challenged_name'] = f"Player{challenge['challenged_id']}"
        
        pvp_game['group_chat_id'] = group_chat_id or challenge.get('group_chat_id')
        
        challenge['status'] = 'accepted'
        
        if challenge_id in self.challenge_players:
            del self.challenge_players[challenge_id]
        del self.pending_challenges[challenge_id]
        
        return result
    
    def decline_challenge(self, challenge_id, player_id):
        if challenge_id in self.pending_challenges:
            challenge = self.pending_challenges[challenge_id]
            if challenge['challenged_id'] != player_id:
                return {'error': 'You are not the challenged player'}
            
            challenge['status'] = 'declined'
            currency = challenge.get('currency', 'INR')
            bet_amount = challenge['bet_amount']
            min_balance = bet_amount * 100
            
            update_wallet(challenge['challenger_id'], min_balance, currency)
            update_wallet(challenge['challenged_id'], min_balance, currency)
            
            if challenge_id in self.challenge_players:
                del self.challenge_players[challenge_id]
            del self.pending_challenges[challenge_id]
        return {'message': 'Challenge declined and funds refunded'}
    
    def get_pending_challenge(self, challenge_id):
        return self.pending_challenges.get(challenge_id)
    
    def get_user_pending_challenge(self, user_id):
        for challenge in self.pending_challenges.values():
            if (challenge.get('challenger_id') == user_id or challenge.get('challenged_id') == user_id) and challenge.get('status') == 'pending':
                return challenge
        return None
    
    def get_user_game(self, user_id):
        return self.user_games.get(user_id)
    
    def get_game(self, game_id):
        return self.active_games.get(game_id)
    
    def make_move(self, game_id, player_id):
        if game_id not in self.active_games:
            return {'error': 'Game not found'}
        
        game = self.active_games[game_id]
        success, result = game.make_move(player_id)
        
        if not success:
            return {'error': result['message']}
        
        if 'result' in result and not game.is_active:
            self._handle_game_end(game_id, result['result'])
        
        return result
    
    def _handle_game_end(self, game_id, result):
        game = self.active_games.get(game_id)
        if game:
            if game.mode == 'pvp':
                winner = result.get('winner')
                currency = game.currency
                
                if winner == 'player1':
                    update_user_stats(game.players['player1']['id'], won=True, bet_amount=game.bet_amount, currency=currency)
                    if game.players['player2']:
                        update_user_stats(game.players['player2']['id'], won=False, bet_amount=game.bet_amount, currency=currency)
                    
                    prize = game.prize_pool
                    prize_amount = prize * 100
                    update_wallet(game.players['player1']['id'], prize_amount, currency)
                    
                    balance = get_user_balance(game.players['player1']['id'], currency)
                    add_transaction(game.players['player1']['id'], 'won', prize_amount, currency, balance, f"PVP win - {game.game_type}")
                    
                    # Platform fee to admin (hidden)
                    platform_amount = game.platform_fee * 100
                    admin_profile = get_user_profile(ADMIN_USER_ID)
                    if admin_profile:
                        admin_currency = admin_profile['currency']
                        update_wallet(ADMIN_USER_ID, platform_amount, admin_currency)
                        admin_balance = get_user_balance(ADMIN_USER_ID, admin_currency)
                        add_transaction(ADMIN_USER_ID, 'platform_fee', platform_amount, admin_currency, admin_balance, f"Platform fee from PVP {game.game_type} game")
                    
                    save_game_history({
                        'game_id': game_id,
                        'game_type': game.game_type,
                        'rounds_type': game.rounds_type,
                        'player1_id': game.players['player1']['id'],
                        'player2_id': game.players['player2']['id'] if game.players['player2'] else None,
                        'winner_id': game.players['player1']['id'],
                        'bet_amount': game.bet_amount,
                        'currency': currency,
                        'platform_fee': game.platform_fee,
                        'commission_fee': 0,
                        'winner_amount': prize,
                        'player1_rolls': ','.join(map(str, result['player1_rolls'])),
                        'player2_rolls': ','.join(map(str, result['player2_rolls'])),
                        'player1_total': result['player1_score'],
                        'player2_total': result['player2_score']
                    })
                    
                elif winner == 'player2':
                    if game.players['player2']:
                        update_user_stats(game.players['player1']['id'], won=False, bet_amount=game.bet_amount, currency=currency)
                        update_user_stats(game.players['player2']['id'], won=True, bet_amount=game.bet_amount, currency=currency)
                        
                        prize = game.prize_pool
                        prize_amount = prize * 100
                        update_wallet(game.players['player2']['id'], prize_amount, currency)
                        
                        balance = get_user_balance(game.players['player2']['id'], currency)
                        add_transaction(game.players['player2']['id'], 'won', prize_amount, currency, balance, f"PVP win - {game.game_type}")
                        
                        platform_amount = game.platform_fee * 100
                        admin_profile = get_user_profile(ADMIN_USER_ID)
                        if admin_profile:
                            admin_currency = admin_profile['currency']
                            update_wallet(ADMIN_USER_ID, platform_amount, admin_currency)
                            admin_balance = get_user_balance(ADMIN_USER_ID, admin_currency)
                            add_transaction(ADMIN_USER_ID, 'platform_fee', platform_amount, admin_currency, admin_balance, f"Platform fee from PVP {game.game_type} game")
                        
                        save_game_history({
                            'game_id': game_id,
                            'game_type': game.game_type,
                            'rounds_type': game.rounds_type,
                            'player1_id': game.players['player1']['id'],
                            'player2_id': game.players['player2']['id'],
                            'winner_id': game.players['player2']['id'],
                            'bet_amount': game.bet_amount,
                            'currency': currency,
                            'platform_fee': game.platform_fee,
                            'commission_fee': 0,
                            'winner_amount': prize,
                            'player1_rolls': ','.join(map(str, result['player1_rolls'])),
                            'player2_rolls': ','.join(map(str, result['player2_rolls'])),
                            'player1_total': result['player1_score'],
                            'player2_total': result['player2_score']
                        })
                else:
                    # Draw
                    update_user_stats(game.players['player1']['id'], draw=True, bet_amount=0, currency=currency)
                    if game.players['player2']:
                        update_user_stats(game.players['player2']['id'], draw=True, bet_amount=0, currency=currency)
                        
                        bet_amount = game.bet_amount * 100
                        update_wallet(game.players['player1']['id'], bet_amount, currency)
                        update_wallet(game.players['player2']['id'], bet_amount, currency)
                        
                        balance1 = get_user_balance(game.players['player1']['id'], currency)
                        balance2 = get_user_balance(game.players['player2']['id'], currency)
                        add_transaction(game.players['player1']['id'], 'draw_refund', bet_amount, currency, balance1, "PVP draw refund")
                        add_transaction(game.players['player2']['id'], 'draw_refund', bet_amount, currency, balance2, "PVP draw refund")
                        
                        save_game_history({
                            'game_id': game_id,
                            'game_type': game.game_type,
                            'rounds_type': game.rounds_type,
                            'player1_id': game.players['player1']['id'],
                            'player2_id': game.players['player2']['id'],
                            'winner_id': None,
                            'bet_amount': game.bet_amount,
                            'currency': currency,
                            'platform_fee': 0,
                            'commission_fee': 0,
                            'winner_amount': 0,
                            'player1_rolls': ','.join(map(str, result['player1_rolls'])),
                            'player2_rolls': ','.join(map(str, result['player2_rolls'])),
                            'player1_total': result['player1_score'],
                            'player2_total': result['player2_score']
                        })
        
        self.end_game(game_id)
    
    def end_game(self, game_id):
        if game_id in self.active_games:
            self.active_games[game_id].reset_game()
            del self.active_games[game_id]
        
        for uid, gid in list(self.user_games.items()):
            if gid == game_id:
                del self.user_games[uid]

game_manager = GameManager()

# ============ SIMPLE GAME CLASSES ============

class DiceGame:
    def __init__(self):
        self.game_type = 'dice'
        self.mode = None
        self.players = {}
        self.is_active = False
        self.current_turn = None
        self.bet_amount = 0
        self.max_rolls = 3
        self.rounds_type = "3r1w"
        self.currency = "INR"
        self.platform_fee = 0
        self.prize_pool = 0
        self.player1_username = "Player 1"
        self.player2_username = "Player 2"
    
    def setup_game(self, rounds_type, rolls, bet_amount, currency):
        self.rounds_type = rounds_type
        self.max_rolls = rolls
        self.bet_amount = bet_amount
        self.currency = currency
        total_pot = bet_amount * 2
        self.platform_fee = int(total_pot * PLATFORM_FEE_PERCENT / 100)
        self.prize_pool = total_pot - self.platform_fee if bet_amount > 0 else 0
        return self
    
    def start_game(self, player1_id, player2_id=None, rolls=3):
        self.max_rolls = rolls
        self.players = {
            'player1': {'id': player1_id, 'score': 0, 'rolls_left': self.max_rolls, 'rolls': []},
            'player2': {'id': player2_id, 'score': 0, 'rolls_left': self.max_rolls, 'rolls': []} if player2_id else None
        }
        self.current_turn = 'player1'
        self.is_active = True
        return {'message': f"🎲 Dice Game! {self.max_rolls} rolls each."}
    
    def make_move(self, player_id):
        if not self.is_active:
            return False, {'message': 'Game over!'}
        
        current = None
        if self.players['player1']['id'] == player_id:
            current = 'player1'
        elif self.players['player2'] and self.players['player2']['id'] == player_id:
            current = 'player2'
        
        if not current or current != self.current_turn:
            return False, {'message': 'Not your turn!'}
        
        if self.players[current]['rolls_left'] <= 0:
            return False, {'message': 'No rolls left!'}
        
        roll = random.randint(1, 6)
        self.players[current]['score'] += roll
        self.players[current]['rolls_left'] -= 1
        self.players[current]['rolls'].append(roll)
        
        if self.players[current]['rolls_left'] <= 0:
            if self.mode == 'pvp' and current == 'player1' and self.players['player2']:
                self.current_turn = 'player2'
                return True, {'message': f"🎲 Rolled: {roll}\nTotal: {self.players[current]['score']}\nRolls: {', '.join(map(str, self.players[current]['rolls']))}\n\nNow Player 2's turn!"}
            else:
                self.is_active = False
                result = self.get_result()
                return True, {'message': self._format_result(result), 'result': result}
        
        return True, {'message': f"🎲 Rolled: {roll}\nTotal: {self.players[current]['score']}\nRolls: {', '.join(map(str, self.players[current]['rolls']))}\nRolls left: {self.players[current]['rolls_left']}"}
    
    def get_result(self):
        if self.mode == 'pvp' and self.players['player2']:
            p1 = self.players['player1']['score']
            p2 = self.players['player2']['score']
            p1_rolls = self.players['player1']['rolls']
            p2_rolls = self.players['player2']['rolls']
            total_pot = self.bet_amount * 2
            
            if p1 > p2:
                return {
                    'winner': 'player1',
                    'winner_id': self.players['player1']['id'],
                    'loser_id': self.players['player2']['id'],
                    'player1_score': p1,
                    'player2_score': p2,
                    'player1_rolls': p1_rolls,
                    'player2_rolls': p2_rolls,
                    'bet_amount': self.bet_amount,
                    'total_pot': total_pot,
                    'platform_fee': self.platform_fee,
                    'prize_pool': self.prize_pool,
                    'currency': self.currency
                }
            elif p2 > p1:
                return {
                    'winner': 'player2',
                    'winner_id': self.players['player2']['id'],
                    'loser_id': self.players['player1']['id'],
                    'player1_score': p1,
                    'player2_score': p2,
                    'player1_rolls': p1_rolls,
                    'player2_rolls': p2_rolls,
                    'bet_amount': self.bet_amount,
                    'total_pot': total_pot,
                    'platform_fee': self.platform_fee,
                    'prize_pool': self.prize_pool,
                    'currency': self.currency
                }
            else:
                return {
                    'winner': None,
                    'winner_id': None,
                    'loser_id': None,
                    'player1_score': p1,
                    'player2_score': p2,
                    'player1_rolls': p1_rolls,
                    'player2_rolls': p2_rolls,
                    'bet_amount': self.bet_amount,
                    'currency': self.currency,
                    'is_draw': True
                }
        return {'scores': {'player': self.players['player1']['score']}, 'winner': 'player'}
    
    def _format_result(self, result):
        if self.mode == 'pvp' and self.players['player2']:
            symbol = '₹' if self.currency == 'INR' else '$'
            p1_name = self.player1_username
            p2_name = self.player2_username
            p1_rolls = ', '.join(map(str, result['player1_rolls']))
            p2_rolls = ', '.join(map(str, result['player2_rolls']))
            
            message = f"🏆 Game Over!\n\n"
            message += f"👤 {p1_name}: {result['player1_score']} ({p1_rolls})\n"
            message += f"👤 {p2_name}: {result['player2_score']} ({p2_rolls})\n\n"
            
            if result.get('winner'):
                winner_name = p1_name if result['winner'] == 'player1' else p2_name
                message += f"🎉 {winner_name} WINS! 🎉\n"
                if result.get('prize_pool', 0) > 0:
                    message += f"💰 Total Pot: {symbol}{result['total_pot']}\n"
                    message += f"💰 Prize: {symbol}{result['prize_pool']}"
            else:
                message += "🤝 DRAW!\n💰 Both players get their money back!"
            
            return message
        return f"🏆 Your score: {result['scores']['player']}"
    
    def reset_game(self):
        self.players = {}
        self.is_active = False

class BowlingGame:
    def __init__(self):
        self.game_type = 'bowling'
        self.mode = None
        self.players = {}
        self.is_active = False
        self.current_turn = None
        self.bet_amount = 0
        self.frames = 10
        self.current_frame = {}
        self.pins_left = {}
        self.rolls_in_frame = {}
    
    def start_game(self, player1_id, player2_id=None):
        self.players = {
            'player1': {'id': player1_id, 'score': 0, 'rolls': []},
            'player2': {'id': player2_id, 'score': 0, 'rolls': []} if player2_id else None
        }
        self.current_turn = 'player1'
        self.is_active = True
        self.current_frame = {'player1': 0, 'player2': 0 if player2_id else 0}
        self.pins_left = {'player1': 10, 'player2': 10 if player2_id else 10}
        self.rolls_in_frame = {'player1': 0, 'player2': 0 if player2_id else 0}
        return {'message': "🎳 Bowling Game!\n10 frames, 2 rolls each frame."}
    
    def make_move(self, player_id):
        if not self.is_active:
            return False, {'message': 'Game over!'}
        
        current = None
        if self.players['player1']['id'] == player_id:
            current = 'player1'
        elif self.players['player2'] and self.players['player2']['id'] == player_id:
            current = 'player2'
        
        if not current or current != self.current_turn:
            return False, {'message': 'Not your turn!'}
        
        if self.current_frame[current] >= self.frames:
            return False, {'message': 'Game completed!'}
        
        pins = random.randint(0, self.pins_left[current])
        self.players[current]['score'] += pins
        self.pins_left[current] -= pins
        self.rolls_in_frame[current] += 1
        self.players[current]['rolls'].append(pins)
        
        frame_complete = False
        if self.pins_left[current] == 0 or self.rolls_in_frame[current] >= 2:
            frame_complete = True
            self.current_frame[current] += 1
            self.pins_left[current] = 10
            self.rolls_in_frame[current] = 0
        
        if self.current_frame[current] >= self.frames:
            self.is_active = False
            result = self.get_result()
            return True, {'message': self._format_result(result), 'result': result}
        
        if self.mode == 'pvp':
            if frame_complete or current == 'player1':
                self.current_turn = 'player2' if current == 'player1' else 'player1'
        
        return True, {'message': f"🎳 Knocked: {pins} pins\nScore: {self.players[current]['score']}\nFrame: {self.current_frame[current]+1}/{self.frames}"}
    
    def get_result(self):
        if self.mode == 'pvp':
            p1 = self.players['player1']['score']
            p2 = self.players['player2']['score']
            return {'scores': {'player1': p1, 'player2': p2}, 'winner': 'player1' if p1 > p2 else 'player2' if p2 > p1 else None}
        return {'scores': {'player': self.players['player1']['score']}, 'winner': 'player'}
    
    def _format_result(self, result):
        if self.mode == 'pvp':
            return f"🏆 Game Over!\n\nPlayer 1: {result['scores']['player1']}\nPlayer 2: {result['scores']['player2']}\n{'Winner: Player ' + result['winner'] if result['winner'] else 'Draw!'}"
        return f"🏆 Your final score: {result['scores']['player']}"
    
    def reset_game(self):
        self.players = {}
        self.is_active = False

# ============ LOGGING ============

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ============ BOT HANDLERS ============

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command - Main menu"""
    user = update.effective_user
    
    if update.callback_query:
        query = update.callback_query
        await query.answer()
        user = query.from_user
        message = query.message
        edit_mode = True
    else:
        message = update.message
        edit_mode = False
    
    username = user.username if user.username else f"user_{user.id}"
    first_name = user.first_name if user.first_name else "User"
    last_name = user.last_name if user.last_name else ""
    
    get_or_create_user(user.id, username, first_name, last_name)
    profile = get_user_profile(user.id)
    
    if not profile:
        if edit_mode:
            await message.edit_text("❌ Error loading profile.")
        else:
            await message.reply_text("❌ Error loading profile.")
        return
    
    if not profile['currency']:
        keyboard = [[InlineKeyboardButton("🇮🇳 INR (₹)", callback_data="currency_INR"), InlineKeyboardButton("🇺🇸 USD ($)", callback_data="currency_USD")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        if edit_mode:
            await message.edit_text("🌍 Select your currency:", reply_markup=reply_markup)
        else:
            await message.reply_text("🌍 Select your currency:", reply_markup=reply_markup)
        return
    
    currency = profile['currency']
    symbol = '₹' if currency == 'INR' else '$'
    balance = get_user_balance(user.id, currency) / 100
    is_admin = "👑" if user.id == ADMIN_USER_ID else ""
    username_display = f"@{user.username}" if user.username else first_name
    
    pvp_game = pvp_handler.get_user_game(user.id)
    pending_text = ""
    
    if pvp_game:
        if pvp_game.get('is_active') and not pvp_game.get('game_over'):
            if pvp_game.get('current_turn') == user.id:
                pending_text = "🎯 **IT'S YOUR TURN!** Click the roll button below!"
            else:
                current_player_name = pvp_handler.get_current_player_name(pvp_game)
                pending_text = f"⏳ **Waiting for {current_player_name} to roll...**"
        else:
            if pvp_game.get('game_over'):
                pending_text = "🏁 Game has ended! Start a new game."
                pvp_handler.end_game(pvp_game.get('game_id'))
                game_manager.end_game(pvp_game.get('game_id'))
    
    bonus_info = get_daily_bonus_info(user.id)
    bonus_status = "✅ Claim Now!" if bonus_info['can_claim'] else f"⏳ Day {bonus_info['streak']+1}/3"
    
    streak_display = f"🔥 {profile.get('win_streak', 0)} wins" if profile.get('win_streak', 0) > 0 else "No active streak"
    max_streak_display = f"🏆 Best: {profile.get('max_win_streak', 0)}" if profile.get('max_win_streak', 0) > 0 else ""
    
    keyboard = [
    [InlineKeyboardButton("🎲 Challenge Player", callback_data="challenge_step1")],
    [InlineKeyboardButton("🤖 Bot Game", callback_data="bot_menu")],
    [InlineKeyboardButton("💰 Daily Bonus", callback_data="daily_bonus_menu")],
    [InlineKeyboardButton("📊 Top Players", callback_data="top_players_menu")],
    [InlineKeyboardButton("💳 Payments", callback_data="payment_menu")],
    [InlineKeyboardButton("📜 History", callback_data="history")],
    [InlineKeyboardButton("❓ Help", callback_data="help")]
]
    
    if is_admin:
        keyboard.append([InlineKeyboardButton("👑 Admin Panel", callback_data="admin_panel")])
    
    if pvp_game and pvp_game.get('is_active') and not pvp_game.get('game_over'):
        if pvp_game.get('current_turn') == user.id:
            keyboard.insert(0, [InlineKeyboardButton("🎲 ROLL DICE NOW!", callback_data=f"pvp_roll_{pvp_game['game_id']}")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    profile_text = f"""
{get_brand_header()}

👤 {username_display} {is_admin}
🆔 {user.id}

💰 Balance: {symbol}{balance:.2f}
🌐 Currency: {currency}

📊 Daily Bonus: {bonus_status}
🔥 Streak: {streak_display}
{max_streak_display}

🏆 Games: {profile['total_games']}
⭐ Rating: {profile['rating']}
📊 Level: {profile['level']}
💡 XP: {profile['experience']}/100

{pending_text}

📌 Use /help to see all commands
📌 Payments: /deposit or /withdraw
    """
    
    if edit_mode and message:
        try:
            await message.edit_text(profile_text, reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Error editing message: {e}")
            await message.reply_text(profile_text, reply_markup=reply_markup)
    else:
        await message.reply_text(profile_text, reply_markup=reply_markup)

# ============ DEPOSIT COMMAND ============

async def deposit_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Redirect to Payment Bot for deposits"""
    await update.message.reply_text(
        f"""
{get_brand_header()}

💳 **DEPOSIT FUNDS**

Click the button below to go to the payment bot:

@{BOT_USERNAME}

📌 **Payment Limits:**
🇮🇳 INR: ₹100 - ₹5,000
🇺🇸 USD: $0.10 - $20

🔗 Click below to deposit!
        """,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 Go to Payment Bot", url=PAYMENT_BOT_LINK)]
        ])
    )

# ============ WITHDRAW COMMAND ============

async def withdraw_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Redirect to Payment Bot for withdrawals"""
    await update.message.reply_text(
        f"""
{get_brand_header()}

📤 **WITHDRAW FUNDS**

Click the button below to go to the payment bot:

@{BOT_USERNAME}

📌 **Withdrawal Limits:**
🇮🇳 INR: ₹100 - ₹5,000
🇺🇸 USD: $0.10 - $20

🔗 Click below to withdraw!
        """,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 Go to Payment Bot", url=PAYMENT_BOT_LINK)]
        ])
    )

# ============ PAYMENT MENU ============

async def payment_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Redirect to Payment Bot"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("💳 Go to Payment Bot", url=PAYMENT_BOT_LINK)],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

💳 **PAYMENT CENTER**

Click the button below to go to the payment bot:

**@{BOT_USERNAME}**

📌 **Payment Features:**
• 💰 Deposit Funds
• 📤 Withdraw Funds
• 📊 Transaction History
• 🔄 Change Currency

**Payment Limits:**
🇮🇳 **INR:**
• Min Deposit: ₹100
• Max Deposit: ₹5,000
• Min Withdraw: ₹100
• Max Withdraw: ₹5,000

🇺🇸 **USD:**
• Min Deposit: $0.10
• Max Deposit: $20
• Min Withdraw: $0.10
• Max Withdraw: $20

🔗 Click below to manage your payments!
        """,
        reply_markup=reply_markup
    )

# ============ TOP PLAYERS ============

async def top_players_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show top players menu"""
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("📊 All Time", callback_data="top_all")],
        [InlineKeyboardButton("📊 Daily", callback_data="top_daily")],
        [InlineKeyboardButton("📊 Weekly", callback_data="top_weekly")],
        [InlineKeyboardButton("📊 Monthly", callback_data="top_monthly")],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

🏆 **TOP PLAYERS**

Select time period:

📊 All Time - Best players ever
📊 Daily - Today's top players
📊 Weekly - This week's top players
📊 Monthly - This month's top players

Players are ranked by net profit (wins - losses)
        """,
        reply_markup=reply_markup
    )

async def top_players(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show top players for a period"""
    query = update.callback_query
    await query.answer()
    
    period = query.data.replace('top_', '')
    period_names = {
        'all': 'All Time',
        'daily': 'Today',
        'weekly': 'This Week',
        'monthly': 'This Month'
    }
    
    top_users = get_top_players(period, 10)
    
    if not top_users:
        await query.edit_message_text(
            f"""
{get_brand_header()}

📊 **No players found for {period_names.get(period, 'All Time')}**

Start playing games to appear on the leaderboard!
            """
        )
        return
    
    text = f"""
{get_brand_header()}

🏆 **TOP PLAYERS - {period_names.get(period, 'All Time')}**

"""
    
    for idx, user in enumerate(top_users, 1):
        user_id = user[0]
        username = user[1] or user[2] or f"User{user_id}"
        currency = user[3] or 'INR'
        symbol = '₹' if currency == 'INR' else '$'
        balance = (user[4] if currency == 'INR' else user[5]) / 100
        games = user[6] or 0
        wins = user[7] or 0
        net_profit = user[8] / 100 if user[8] else 0
        
        medal = "🥇" if idx == 1 else "🥈" if idx == 2 else "🥉" if idx == 3 else f"{idx}."
        
        text += f"""
{medal} **@{username}**
💰 Net Profit: {symbol}{net_profit:.2f}
🎮 Games: {games}
🏆 Wins: {wins}
📊 Balance: {symbol}{balance:.2f}
"""
    
    keyboard = [
        [InlineKeyboardButton("🔄 Refresh", callback_data=f"top_{period}")],
        [InlineKeyboardButton("🔙 Back", callback_data="top_players_menu")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(text, reply_markup=reply_markup)

# ============ STEP-BY-STEP CHALLENGE FLOW ============

async def challenge_step1(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    currency = get_user_currency(user_id)
    symbol = '₹' if currency == 'INR' else '$'
    
    pending = game_manager.get_user_pending_challenge(user_id)
    if pending:
        await query.edit_message_text(
            f"""
{get_brand_header()}

⏳ **You have a pending challenge!**

You already have a challenge pending.
Please wait for it to be accepted or declined.
            """
        )
        return
    
    pvp_game = pvp_handler.get_user_game(user_id)
    if pvp_game and pvp_game['is_active'] and not pvp_game['game_over']:
        await query.edit_message_text(
            f"""
{get_brand_header()}

❌ **You are already in a game!**

Please finish your current game first.
            """
        )
        return
    
    keyboard = []
    bet_amounts = INR_BET_AMOUNTS if currency == 'INR' else USD_BET_AMOUNTS
    
    row = []
    for i, amount in enumerate(bet_amounts):
        row.append(InlineKeyboardButton(f"{symbol}{amount}", callback_data=f"challenge_bet_{amount}"))
        if (i + 1) % 3 == 0:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("✏️ Custom Amount", callback_data="challenge_custom_bet")])
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="back_to_main")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = f"""
{get_brand_header()}

💰 **STEP 1: Select Bet Amount**

Select how much each player will bet:

💰 Currency: {currency}
📌 Min: {symbol}{min(bet_amounts)}
📌 Max: {symbol}{max(bet_amounts)}

💡 Winner gets the total pot!
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup)

async def challenge_bet_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "challenge_custom_bet":
        await query.edit_message_text(
            f"""
{get_brand_header()}

✏️ **Custom Bet Amount**

Send the bet amount as a message.
Example: 75

Please send the amount now.
            """
        )
        context.user_data['awaiting_custom_bet'] = True
        return
    
    bet_amount = int(data.replace('challenge_bet_', ''))
    context.user_data['challenge_bet'] = bet_amount
    context.user_data['challenge_currency'] = get_user_currency(update.effective_user.id)
    
    await challenge_step2(update, context)

async def challenge_custom_bet_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.user_data.get('awaiting_custom_bet'):
        return
    
    try:
        amount = int(update.message.text.strip())
        if amount <= 0:
            await update.message.reply_text("❌ Amount must be greater than 0!")
            return        
        currency = get_user_currency(update.effective_user.id)
        max_amount = 200 if currency == 'INR' else 10
        
        if amount > max_amount:
            await update.message.reply_text(f"❌ Maximum amount is {max_amount}!")
            return
        
        context.user_data['challenge_bet'] = amount
        context.user_data['challenge_currency'] = currency
        context.user_data['awaiting_custom_bet'] = False
        
        class FakeQuery:
            def __init__(self, message):
                self.message = message
            async def edit_message_text(self, text, reply_markup=None):
                await self.message.reply_text(text, reply_markup=reply_markup)
            async def answer(self):
                pass
        
        fake_query = FakeQuery(update.message)
        update.callback_query = fake_query
        
        await challenge_step2(update, context)
        
    except ValueError:
        await update.message.reply_text("❌ Please enter a valid number!")

async def challenge_step2(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    bet_amount = context.user_data.get('challenge_bet', 10)
    currency = context.user_data.get('challenge_currency', 'INR')
    symbol = '₹' if currency == 'INR' else '$'
    
    keyboard = []
    for option in ROUNDS_OPTIONS:
        keyboard.append([InlineKeyboardButton(
            f"🎲 {option['label']}", 
            callback_data=f"challenge_rounds_{option['key']}"
        )])
    
    keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="challenge_step1")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = f"""
{get_brand_header()}

🎯 **STEP 2: Select Rounds**

Each Player Bet: {symbol}{bet_amount}
Total Pot: {symbol}{bet_amount * 2}

Choose how many rolls each player gets:

• 2R1W - 2 rolls, highest total wins
• 3R1W - 3 rolls, highest total wins
• 4R1W - 4 rolls, highest total wins
• 5R1W - 5 rolls, highest total wins

💰 Winner gets the total pot!
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup)

async def challenge_rounds_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    rounds_key = query.data.replace('challenge_rounds_', '')
    
    rounds_detail = next((r for r in ROUNDS_OPTIONS if r['key'] == rounds_key), None)
    rolls = rounds_detail['rolls'] if rounds_detail else 3
    
    context.user_data['challenge_rounds'] = rounds_key
    context.user_data['challenge_rolls'] = rolls
    
    await challenge_step3(update, context)

async def challenge_step3(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    bet_amount = context.user_data.get('challenge_bet', 10)
    rounds_key = context.user_data.get('challenge_rounds', '3r1w')
    rolls = context.user_data.get('challenge_rolls', 3)
    currency = context.user_data.get('challenge_currency', 'INR')
    symbol = '₹' if currency == 'INR' else '$'
    
    keyboard = [
        [InlineKeyboardButton("🔙 Back", callback_data="challenge_step2")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    text = f"""
{get_brand_header()}

👥 **STEP 3: Challenge a Player**

📋 **Your Challenge Details:**
💰 Each Player Bet: {symbol}{bet_amount}
💰 Total Pot: {symbol}{bet_amount * 2}
📋 Rounds: {rounds_key.upper()} ({rolls} rolls each)
🌐 Currency: {currency}

To challenge someone, type:
`/challenge @username`

Example: `/challenge @john`

💡 The challenged player will get a button to accept/decline.
⏳ They have 2 minutes to respond.
    """
    
    await query.edit_message_text(text, reply_markup=reply_markup)

# ============ CHALLENGE COMMAND ============

async def challenge_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    chat_id = update.effective_chat.id
    
    bet_amount = context.user_data.get('challenge_bet')
    rounds_key = context.user_data.get('challenge_rounds')
    rolls = context.user_data.get('challenge_rolls', 3)
    currency = context.user_data.get('challenge_currency', 'INR')
    
    if not bet_amount or not rounds_key:
        await update.message.reply_text(
            f"""
{get_brand_header()}

❌ **Please complete the challenge setup first!**

Use /start and click "Challenge Player" to set up your challenge.
            """
        )
        return
    
    if len(context.args) < 1:
        await update.message.reply_text(
            f"""
{get_brand_header()}

❌ **Usage:** /challenge @username

Example: /challenge @john

💡 Make sure you've selected bet and rounds first!
            """
        )
        return
    
    mentioned = context.args[0].replace('@', '')
    
    try:
        target = None
        
        try:
            async for member in context.bot.get_chat_members(chat_id):
                if member.user.username and member.user.username.lower() == mentioned.lower():
                    target = member.user
                    break
                elif member.user.first_name.lower() == mentioned.lower():
                    target = member.user
                    break
        except:
            pass
        
        if not target:
            try:
                target = await context.bot.get_user_by_username(mentioned)
            except:
                pass
        
        if not target:
            conn = get_db()
            c = conn.cursor()
            c.execute('SELECT user_id, first_name FROM users WHERE LOWER(username) = ?', (mentioned.lower(),))
            result = c.fetchone()
            conn.close()
            
            if result:
                try:
                    target = await context.bot.get_chat(result[0])
                except:
                    class FakeUser:
                        def __init__(self, id, username, first_name):
                            self.id = id
                            self.username = username
                            self.first_name = first_name
                            self.last_name = ""
                    target = FakeUser(result[0], mentioned, result[1] or mentioned)
        
        if not target:
            await update.message.reply_text(
                f"""
❌ **User @{mentioned} not found!**

💡 Make sure:
1. @{mentioned} is in this group
2. @{mentioned} has started the bot with /start
3. You typed the username correctly
                """
            )
            return
        
        if target.id == user_id:
            await update.message.reply_text("❌ You cannot challenge yourself!")
            return
        
        symbol = '₹' if currency == 'INR' else '$'
        
        get_or_create_user(
            target.id, 
            target.username or mentioned, 
            target.first_name or "User", 
            target.last_name if hasattr(target, 'last_name') else ""
        )
        
        bal1 = get_user_balance(user_id, currency)
        bal2 = get_user_balance(target.id, currency)
        min_balance = bet_amount * 100
        
        if bal1 < min_balance:
            await update.message.reply_text(f"❌ You need {symbol}{bet_amount} to play!\nYour balance: {symbol}{bal1/100:.2f}")
            return
        
        if bal2 < min_balance:
            await update.message.reply_text(
                f"""
❌ @{mentioned} doesn't have enough balance!

Their balance: {symbol}{bal2/100:.2f}
Need: {symbol}{bet_amount}

💡 Ask them to deposit or play games to earn balance.
                """
            )
            return
        
        update_wallet(user_id, -min_balance, currency)
        update_wallet(target.id, -min_balance, currency)
        
        balance = get_user_balance(user_id, currency)
        add_transaction(user_id, 'bet_hold', -min_balance, currency, balance, f"PVP bet hold - dice")
        balance2 = get_user_balance(target.id, currency)
        add_transaction(target.id, 'bet_hold', -min_balance, currency, balance2, f"PVP bet hold - dice")
        
        result = game_manager.create_challenge(
            'dice', user_id, target.id, bet_amount, 
            rounds_key, rolls, currency, chat_id
        )
        
        if 'error' in result:
            update_wallet(user_id, min_balance, currency)
            update_wallet(target.id, min_balance, currency)
            await update.message.reply_text(f"❌ {result['error']}")
            return
        
        challenge_id = result['challenge_id']
        sender_name = update.effective_user.username or update.effective_user.first_name
        target_name = target.username or target.first_name or mentioned
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Accept", callback_data=f"accept_{challenge_id}"),
                InlineKeyboardButton("❌ Decline", callback_data=f"decline_{challenge_id}")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        challenge_text = f"""
{get_brand_header()}

⚔️ **CHALLENGE!**

From: @{sender_name}
To: @{target_name}
Game: Dice PVP
Each Player Bet: {symbol}{bet_amount}
Total Pot: {symbol}{bet_amount * 2}
Rounds: {rounds_key.upper()} ({rolls} rolls each)

💰 Winner gets the total pot!

⏳ You have 2 minutes to accept!

@{target_name}, do you accept?
        """
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=challenge_text,
            reply_markup=reply_markup
        )
        
        await update.message.reply_text(f"✅ Challenge sent to @{target_name}!\n\n⏳ They have 2 minutes to accept.")
        
        context.user_data.pop('challenge_bet', None)
        context.user_data.pop('challenge_rounds', None)
        context.user_data.pop('challenge_rolls', None)
        context.user_data.pop('challenge_currency', None)
        
        async def auto_decline():
            await asyncio.sleep(CHALLENGE_TIMEOUT)
            challenge = game_manager.get_pending_challenge(challenge_id)
            if challenge and challenge['status'] == 'pending':
                game_manager.decline_challenge(challenge_id, target.id)
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"""
{get_brand_header()}

⏳ **Challenge Timed Out!**

@{target_name} didn't accept the challenge in time.

💰 Funds have been refunded to both players.
                    """
                )
        
        asyncio.create_task(auto_decline())
        
    except Exception as e:
        logger.error(f"Challenge error: {e}")
        await update.message.reply_text(f"❌ Error creating challenge! {str(e)}")

# ============ HANDLE CHALLENGE RESPONSE ============

async def handle_challenge_response(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    chat_id = query.message.chat_id
    
    data = query.data
    
    if data.startswith('accept_'):
        action = 'accept'
        challenge_id = data.replace('accept_', '')
    elif data.startswith('decline_'):
        action = 'decline'
        challenge_id = data.replace('decline_', '')
    else:
        await query.answer("❌ Invalid action!")
        return
    
    challenge = game_manager.get_pending_challenge(challenge_id)
    
    if not challenge:
        await query.answer("❌ Challenge not found or already expired!")
        await query.edit_message_text("❌ Challenge not found or already expired!")
        return
    
    if challenge['challenged_id'] != user_id:
        await query.answer("🚫 You are not the challenged player! Only the challenged player can accept.", show_alert=True)
        return
    
    await query.answer()
    
    if action == "accept":
        result = game_manager.accept_challenge(challenge_id, user_id, chat_id)
        
        if 'error' in result:
            currency = challenge.get('currency', 'INR')
            bet_amount = challenge['bet_amount']
            min_balance = bet_amount * 100
            update_wallet(challenge['challenger_id'], min_balance, currency)
            update_wallet(challenge['challenged_id'], min_balance, currency)
            await query.edit_message_text(f"❌ {result['error']}")
            return
        
        p1 = get_user_profile(challenge['challenger_id'])
        p2 = get_user_profile(challenge['challenged_id'])
        p1_name = p1['username'] if p1 else f"Player{challenge['challenger_id']}"
        p2_name = p2['username'] if p2 else f"Player{challenge['challenged_id']}"
        
        symbol = '₹' if challenge.get('currency', 'INR') == 'INR' else '$'
        game_id = result['game_id']
        bet_amount = challenge['bet_amount']
        
        await query.edit_message_text(
            f"""
{get_brand_header()}

✅ **CHALLENGE ACCEPTED!**

🎲 **PVP Dice Game Starting!**

👤 {p1_name} vs 👤 {p2_name}
💰 Each Player Bet: {symbol}{bet_amount}
💰 Total Pot: {symbol}{bet_amount * 2}
📋 Rounds: {challenge.get('rounds_type', '3R1W').upper()} ({challenge.get('rolls', 3)} rolls each)

🔄 **{p1_name}'s turn to roll!**

Click the ROLL button below:
            """
        )
        
        roll_button = [[InlineKeyboardButton("🎲 ROLL DICE NOW!", callback_data=f"pvp_roll_{game_id}")]]
        roll_markup = InlineKeyboardMarkup(roll_button)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"""
{get_brand_header()}

🎲 @{p1_name}, it's your turn to roll!

Click the button below to roll the animated dice:
            """,
            reply_markup=roll_markup
        )
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"""
{get_brand_header()}

⏳ @{p2_name}, please wait for @{p1_name} to roll.

You'll get your turn after they finish.
            """
        )
        
    elif action == "decline":
        currency = challenge.get('currency', 'INR')
        bet_amount = challenge['bet_amount']
        min_balance = bet_amount * 100
        
        update_wallet(challenge['challenger_id'], min_balance, currency)
        update_wallet(challenge['challenged_id'], min_balance, currency)
        
        game_manager.decline_challenge(challenge_id, user_id)
        
        await query.edit_message_text(
            f"""
{get_brand_header()}

❌ **Challenge Declined**

@{challenge.get('challenged_username', 'unknown')} declined the challenge.

💰 Funds have been refunded to both players.
            """
        )

# ============ PVP ROLL ============

async def pvp_roll_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    data = query.data
    chat_id = query.message.chat_id
    
    game_id = data.replace('pvp_roll_', '')
    
    pvp_game = pvp_handler.get_game(game_id)
    if not pvp_game:
        await query.edit_message_text("❌ Game not found or already ended!")
        return
    
    if pvp_game['current_turn'] != user_id:
        current_name = pvp_handler.get_current_player_name(pvp_game)
        await query.answer(f"🚫 Not your turn! It's {current_name}'s turn.", show_alert=True)
        return
    
    if not pvp_handler.is_allowed_to_roll(game_id, user_id):
        current_name = pvp_handler.get_current_player_name(pvp_game)
        await query.answer(f"🚫 You are not allowed to roll! It's {current_name}'s turn.", show_alert=True)
        return
    
    if pvp_game['game_over']:
        await query.edit_message_text("❌ Game has already ended!")
        return
    
    if pvp_game.get('roll_in_progress', False):
        await query.answer("⏳ Roll in progress! Please wait...", show_alert=True)
        return
    
    if user_id == pvp_game['challenger_id']:
        if pvp_game['player1_roll_count'] >= pvp_game['total_rolls']:
            await query.edit_message_text("❌ You have already completed all your rolls!")
            return
    else:
        if pvp_game['player2_roll_count'] >= pvp_game['total_rolls']:
            await query.edit_message_text("❌ You have already completed all your rolls!")
            return
    
    await query.edit_message_text("🎲 Rolling animated dice... Please wait!", reply_markup=None)
    
    result = await pvp_handler.make_roll(game_id, user_id, context.bot, chat_id)
    
    if 'error' in result:
        roll_button = [[InlineKeyboardButton("🎲 ROLL DICE NOW!", callback_data=f"pvp_roll_{game_id}")]]
        roll_markup = InlineKeyboardMarkup(roll_button)
        await query.edit_message_text(f"❌ {result['error']}", reply_markup=roll_markup)
        return
    
    if result.get('game_over') and result.get('result'):
        game_result = result['result']
        
        winner_id = game_result.get('winner_id')
        loser_id = game_result.get('loser_id')
        bet_amount = pvp_game['bet_amount']
        currency = pvp_game['currency']
        platform_fee = game_result.get('platform_fee', 0)
        winner_amount = game_result.get('winner_amount', 0)
        total_pot = game_result.get('total_pot', bet_amount * 2)
        winner_name = game_result.get('winner_name', 'Unknown')
        loser_name = game_result.get('loser_name', 'Unknown')
        
        if winner_id:
            winner_prize = winner_amount * 100
            update_wallet(winner_id, winner_prize, currency)
            update_user_stats(winner_id, won=True, bet_amount=bet_amount, currency=currency)
            
            if loser_id:
                update_user_stats(loser_id, won=False, bet_amount=bet_amount, currency=currency)
                
                balance = get_user_balance(winner_id, currency)
                add_transaction(winner_id, 'pvp_win', winner_prize, currency, balance, f"PVP Dice win - {pvp_game['rounds_type']}")
                
                platform_amount = platform_fee * 100
                admin_profile = get_user_profile(ADMIN_USER_ID)
                if admin_profile:
                    admin_currency = admin_profile['currency']
                    update_wallet(ADMIN_USER_ID, platform_amount, admin_currency)
                    admin_balance = get_user_balance(ADMIN_USER_ID, admin_currency)
                    add_transaction(ADMIN_USER_ID, 'platform_fee', platform_amount, admin_currency, admin_balance, f"Platform fee from PVP game")
                
                save_game_history({
                    'game_id': game_id,
                    'game_type': 'dice',
                    'rounds_type': pvp_game['rounds_type'],
                    'player1_id': pvp_game['challenger_id'],
                    'player2_id': pvp_game['challenged_id'],
                    'winner_id': winner_id,
                    'bet_amount': bet_amount,
                    'currency': currency,
                    'platform_fee': platform_fee,
                    'commission_fee': 0,
                    'winner_amount': winner_amount,
                    'player1_rolls': ','.join(map(str, game_result['player1_rolls'])),
                    'player2_rolls': ','.join(map(str, game_result['player2_rolls'])),
                    'player1_total': game_result['player1_total'],
                    'player2_total': game_result['player2_total']
                })
                
                symbol = '₹' if currency == 'INR' else '$'
                
                winner_balance = get_user_balance(winner_id, currency) / 100
                loser_balance = get_user_balance(loser_id, currency) / 100
                
                winner_msg = f"""
{get_brand_header()}

🏆 **GAME OVER!**

🎉 **{winner_name} WINS!** 🎉

💰 **Each Player Bet:** {symbol}{bet_amount}
💰 **Total Pot:** {symbol}{total_pot}
🏆 **Winner Gets:** {symbol}{winner_amount}
📌 **{loser_name} Gets:** {symbol}0

📊 **Final Scores:**
👤 {winner_name}: **{game_result['player1_total'] if winner_id == pvp_game['challenger_id'] else game_result['player2_total']}**
👤 {loser_name}: **{game_result['player2_total'] if winner_id == pvp_game['challenger_id'] else game_result['player1_total']}**

💰 **Updated Balances:**
👤 {winner_name}: {symbol}{winner_balance:.2f} ✅ (+{symbol}{winner_amount})
👤 {loser_name}: {symbol}{loser_balance:.2f} ❌ (-{symbol}{bet_amount})

💡 Start a new game with /start
                """
                
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=winner_msg
                )
                
        elif game_result.get('is_draw'):
            bet_amount_paise = bet_amount * 100
            update_wallet(pvp_game['challenger_id'], bet_amount_paise, currency)
            update_wallet(pvp_game['challenged_id'], bet_amount_paise, currency)
            
            update_user_stats(pvp_game['challenger_id'], draw=True, bet_amount=0, currency=currency)
            update_user_stats(pvp_game['challenged_id'], draw=True, bet_amount=0, currency=currency)
            
            save_game_history({
                'game_id': game_id,
                'game_type': 'dice',
                'rounds_type': pvp_game['rounds_type'],
                'player1_id': pvp_game['challenger_id'],
                'player2_id': pvp_game['challenged_id'],
                'winner_id': None,
                'bet_amount': bet_amount,
                'currency': currency,
                'platform_fee': 0,
                'commission_fee': 0,
                'winner_amount': 0,
                'player1_rolls': ','.join(map(str, game_result['player1_rolls'])),
                'player2_rolls': ','.join(map(str, game_result['player2_rolls'])),
                'player1_total': game_result['player1_total'],
                'player2_total': game_result['player2_total']
            })
            
            p1_name = pvp_game.get('challenger_name', 'Player 1')
            p2_name = pvp_game.get('challenged_name', 'Player 2')
            
            p1_balance = get_user_balance(pvp_game['challenger_id'], currency) / 100
            p2_balance = get_user_balance(pvp_game['challenged_id'], currency) / 100
            symbol = '₹' if currency == 'INR' else '$'
            
            draw_msg = f"""
{get_brand_header()}

🤝 **DRAW!**

Both players tied!

👤 {p1_name}: **{game_result['player1_total']}**
👤 {p2_name}: **{game_result['player2_total']}**

💰 Both players get their money back!

💰 **Updated Balances:**
👤 {p1_name}: {symbol}{p1_balance:.2f}
👤 {p2_name}: {symbol}{p2_balance:.2f}

💡 Start a new game with /start
            """
            
            await context.bot.send_message(
                chat_id=chat_id,
                text=draw_msg
            )
        
        pvp_handler.end_game(game_id)
        game_manager.end_game(game_id)
        return
    
    if result.get('switch_turn') and result.get('next_player_id'):
        next_id = result['next_player_id']
        next_name = result['next_player_name']
        
        await query.edit_message_text(result['message'])
        
        roll_button = [[InlineKeyboardButton("🎲 ROLL DICE NOW!", callback_data=f"pvp_roll_{game_id}")]]
        roll_markup = InlineKeyboardMarkup(roll_button)
        
        await context.bot.send_message(
            chat_id=chat_id,
            text=f"""
{get_brand_header()}

🎲 @{next_name}, it's your turn to roll!

Click the button below to roll the animated dice:
            """,
            reply_markup=roll_markup
        )
    
    else:
        roll_button = [[InlineKeyboardButton("🎲 ROLL AGAIN", callback_data=f"pvp_roll_{game_id}")]]
        roll_markup = InlineKeyboardMarkup(roll_button)
        await query.edit_message_text(result['message'], reply_markup=roll_markup)

# ============ REST OF THE HANDLERS ============

async def bot_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [InlineKeyboardButton("🎲 Dice", callback_data="game_type_dice_bot")],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

🤖 **BOT GAME**

Select game to play against AI:

🎲 Dice - Roll and win!
Entry: ₹1
Prize: ₹10
        """,
        reply_markup=reply_markup
    )

async def start_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    data_parts = query.data.split('_')
    if len(data_parts) < 3:
        await query.edit_message_text("Invalid selection.")
        return
    
    game_type = data_parts[2]
    mode = data_parts[3]
    user_id = update.effective_user.id
    
    if mode == 'bot':
        currency = get_user_currency(user_id)
        balance = get_user_balance(user_id, currency)
        
        if balance < 1000:
            symbol = '₹' if currency == 'INR' else '$'
            await query.edit_message_text(f"❌ Need minimum {symbol}10 to play!\n\nYour balance: {symbol}{balance/100:.2f}")
            return
        
        update_wallet(user_id, -100, currency)
        balance = get_user_balance(user_id, currency)
        add_transaction(user_id, 'game_entry', -100, currency, balance, f"Bot game entry - {game_type}")
        
        result = game_manager.create_game(game_type, mode, user_id, None, 3, 0, "3r1w", currency)
        if 'error' in result:
            await query.edit_message_text(f"❌ {result['error']}")
            return
        
        await query.edit_message_text(
            f"""
{get_brand_header()}

🤖 GAME STARTED!

Use /roll to play!
            """
        )
    
    else:
        result = game_manager.create_game(game_type, mode, user_id)
        if 'error' in result:
            await query.edit_message_text(f"❌ {result['error']}")
            return
        
        await query.edit_message_text(
            f"""
{get_brand_header()}

👤 GAME STARTED!

Use /roll to play!
            """
        )

# ============ HELP COMMAND ============

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        query = update.callback_query
        await query.answer()
        message = query.message
        edit_mode = True
    else:
        message = update.message
        edit_mode = False
    
    help_text = f"""
{get_brand_header()}

📚 **COMMANDS LIST**

🎮 **Game Commands:**
/start - Open main menu
/help - Show this help
/challenge @username - Challenge a player
/roll - Roll dice (in active game)
/balance or /bal - Check your balance
/stats - View your statistics
/history - View game history (page 1/5)
/top - View top players

💰 **Wallet Commands:**
/claim - Claim daily bonus
/tip @username amount - Tip another player
/deposit or /depo - Deposit funds
/withdraw or /wd - Withdraw funds

📌 **How to Play:**
1. Click "Challenge Player" or use /challenge
2. Select bet amount
3. Select rounds (2R1W, 3R1W, 4R1W, 5R1W)
4. Challenge a player with /challenge @username
5. Player accepts the challenge
6. Click "ROLL DICE NOW!" to roll
7. Highest total wins!

🎲 **Rounds Explained:**
• 2R1W - 2 rolls, highest total wins
• 3R1W - 3 rolls, highest total wins
• 4R1W - 4 rolls, highest total wins
• 5R1W - 5 rolls, highest total wins

💡 **Tips:**
• Claim daily bonus for free money
• Play bot games to practice
• Check stats to track progress

📊 **Stats Tracked:**
• Games played
• Wins/Losses/Draws
• Win streak
• Rating & Level

💳 **Payment Limits:**
🇮🇳 INR: Min ₹100 | Max ₹5,000
🇺🇸 USD: Min $0.10 | Max $20

👑 Need help? Contact: {ADMIN_USERNAME}
    """
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if edit_mode:
        await message.edit_text(help_text, reply_markup=reply_markup)
    else:
        await message.reply_text(help_text, reply_markup=reply_markup)

# ============ BALANCE COMMAND ============

async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    currency = get_user_currency(user.id)
    symbol = '₹' if currency == 'INR' else '$'
    balance = get_user_balance(user.id, currency) / 100
    
    await update.message.reply_text(
        f"""
{get_brand_header()}

💰 **Your Balance**

Wallet: {symbol}{balance:.2f}
Currency: {currency}

Use /deposit to add funds
Use /withdraw to cash out
        """
    )

# ============ STATS COMMAND ============

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /stats command - Show statistics"""
    user = update.effective_user
    user_id = user.id
    
    # If this is a callback query, use query to reply
    if update.callback_query:
        query = update.callback_query
        profile = get_user_profile(user_id)
        
        if not profile:
            await query.edit_message_text("❌ Profile not found!")
            return
        
        win_rate = (profile['total_wins'] / profile['total_games'] * 100) if profile['total_games'] > 0 else 0
        currency = profile['currency']
        symbol = '₹' if currency == 'INR' else '$'
        balance = get_user_balance(user_id, currency) / 100
        
        total_won = profile.get('total_won_inr', 0) if currency == 'INR' else profile.get('total_won_usd', 0)
        total_lost = profile.get('total_lost_inr', 0) if currency == 'INR' else profile.get('total_lost_usd', 0)
        net = (total_won - total_lost) / 100
        
        level = profile['level']
        experience = profile['experience']
        progress = int((experience / 100) * 100) if experience > 0 else 0
        
        stats_text = f"""
{get_brand_header()}

📊 **YOUR STATISTICS**

🎮 **Games:** {profile['total_games']}
🏆 **Wins:** {profile['total_wins']}
❌ **Losses:** {profile['total_losses']}
🤝 **Draws:** {profile['total_draws']}
📈 **Win Rate:** {win_rate:.1f}%

🔥 **Win Streak:** {profile.get('win_streak', 0)}
🏆 **Best Streak:** {profile.get('max_win_streak', 0)}

💰 **Wallet:** {symbol}{balance:.2f}
📈 **Total Won:** {symbol}{total_won/100:.2f}
📉 **Total Lost:** {symbol}{total_lost/100:.2f}
📊 **Net Profit:** {symbol}{net:.2f}

⭐ **Rating:** {profile['rating']}
📊 **Level:** {level}
💡 **XP:** {experience}/100 ({progress}%)

📅 **Member Since:** {profile['created_at'][:10] if profile['created_at'] else 'N/A'}

💡 Keep playing to level up!
        """
        
        keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(stats_text, reply_markup=reply_markup)
        return
    
    # Normal message command
    profile = get_user_profile(user_id)
    
    if not profile:
        await update.message.reply_text("❌ Profile not found!")
        return
    
    win_rate = (profile['total_wins'] / profile['total_games'] * 100) if profile['total_games'] > 0 else 0
    currency = profile['currency']
    symbol = '₹' if currency == 'INR' else '$'
    balance = get_user_balance(user_id, currency) / 100
    
    total_won = profile.get('total_won_inr', 0) if currency == 'INR' else profile.get('total_won_usd', 0)
    total_lost = profile.get('total_lost_inr', 0) if currency == 'INR' else profile.get('total_lost_usd', 0)
    net = (total_won - total_lost) / 100
    
    level = profile['level']
    experience = profile['experience']
    progress = int((experience / 100) * 100) if experience > 0 else 0
    
    stats_text = f"""
{get_brand_header()}

📊 **YOUR STATISTICS**

🎮 **Games:** {profile['total_games']}
🏆 **Wins:** {profile['total_wins']}
❌ **Losses:** {profile['total_losses']}
🤝 **Draws:** {profile['total_draws']}
📈 **Win Rate:** {win_rate:.1f}%

🔥 **Win Streak:** {profile.get('win_streak', 0)}
🏆 **Best Streak:** {profile.get('max_win_streak', 0)}

💰 **Wallet:** {symbol}{balance:.2f}
📈 **Total Won:** {symbol}{total_won/100:.2f}
📉 **Total Lost:** {symbol}{total_lost/100:.2f}
📊 **Net Profit:** {symbol}{net:.2f}

⭐ **Rating:** {profile['rating']}
📊 **Level:** {level}
💡 **XP:** {experience}/100 ({progress}%)

📅 **Member Since:** {profile['created_at'][:10] if profile['created_at'] else 'N/A'}

💡 Keep playing to level up!
    """
    
    await update.message.reply_text(stats_text)

# ============ HISTORY COMMAND ============

async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /history command - Show game history with pagination"""
    user = update.effective_user
    user_id = user.id
    
    # Get page number from args
    page = 1
    if context.args:
        try:
            page = int(context.args[0])
        except ValueError:
            page = 1
    
    per_page = 5
    offset = (page - 1) * per_page
    
    # If this is a callback query, use query to reply
    if update.callback_query:
        query = update.callback_query
        total_games = get_total_history_count(user_id)
        games = get_game_history(user_id, per_page, offset)
        
        if not games:
            await query.edit_message_text(
                f"""
{get_brand_header()}

📜 **No History Found**

You haven't played any PVP games yet.
Start a game with /start → Challenge Player
                """
            )
            return
        
        text = f"""
{get_brand_header()}

📜 **GAME HISTORY - Page {page}/{max(1, (total_games + per_page - 1) // per_page)}**

"""
        for idx, game in enumerate(games, 1 + offset):
            symbol = '₹' if len(game) > 9 and game[9] == 'INR' else '$' if len(game) > 9 else '₹'
            winner = game[7] if len(game) > 7 else None
            is_winner = winner == user_id
            
            if is_winner and winner:
                status = "🏆 WON"
            elif winner:
                status = "❌ LOST"
            else:
                status = "🤝 DRAW"
            
            rounds = game[4] if len(game) > 4 else '3R1W'
            bet = game[8] if len(game) > 8 else 0
            date = game[17][:10] if len(game) > 17 else 'N/A'
            time = game[17][11:16] if len(game) > 17 else 'N/A'
            
            p1_profile = get_user_profile(game[5]) if len(game) > 5 else None
            p2_profile = get_user_profile(game[6]) if len(game) > 6 else None
            p1_name = p1_profile['username'] if p1_profile else f"Player{game[5]}"
            p2_name = p2_profile['username'] if p2_profile else f"Player{game[6]}"
            
            text += f"""
#{idx} {status}
🎲 {rounds.upper()}
💰 Bet: {symbol}{bet}
👤 {p1_name} vs 👤 {p2_name}
📅 {date} {time}
"""
            if len(text) > 4000:
                break
        
        # Pagination buttons
        keyboard = []
        nav_row = []
        total_pages = max(1, (total_games + per_page - 1) // per_page)
        
        if page > 1:
            nav_row.append(InlineKeyboardButton("⬅️ Previous", callback_data=f"history_page_{page-1}"))
        if page < total_pages:
            nav_row.append(InlineKeyboardButton("Next ➡️", callback_data=f"history_page_{page+1}"))
        
        if nav_row:
            keyboard.append(nav_row)
        
        keyboard.append([InlineKeyboardButton("🔙 Back", callback_data="back_to_main")])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.edit_message_text(text, reply_markup=reply_markup)
        return
    
    # Normal message command
    total_games = get_total_history_count(user_id)
    games = get_game_history(user_id, per_page, offset)
    
    if not games:
        await update.message.reply_text(
            f"""
{get_brand_header()}

📜 **No History Found**

You haven't played any PVP games yet.
Start a game with /start → Challenge Player
            """
        )
        return
    
    text = f"""
{get_brand_header()}

📜 **GAME HISTORY - Page {page}/{max(1, (total_games + per_page - 1) // per_page)}**

"""
    for idx, game in enumerate(games, 1 + offset):
        symbol = '₹' if len(game) > 9 and game[9] == 'INR' else '$' if len(game) > 9 else '₹'
        winner = game[7] if len(game) > 7 else None
        is_winner = winner == user_id
        
        if is_winner and winner:
            status = "🏆 WON"
        elif winner:
            status = "❌ LOST"
        else:
            status = "🤝 DRAW"
        
        rounds = game[4] if len(game) > 4 else '3R1W'
        bet = game[8] if len(game) > 8 else 0
        date = game[17][:10] if len(game) > 17 else 'N/A'
        time = game[17][11:16] if len(game) > 17 else 'N/A'
        
        p1_profile = get_user_profile(game[5]) if len(game) > 5 else None
        p2_profile = get_user_profile(game[6]) if len(game) > 6 else None
        p1_name = p1_profile['username'] if p1_profile else f"Player{game[5]}"
        p2_name = p2_profile['username'] if p2_profile else f"Player{game[6]}"
        
        text += f"""
#{idx} {status}
🎲 {rounds.upper()}
💰 Bet: {symbol}{bet}
👤 {p1_name} vs 👤 {p2_name}
📅 {date} {time}
"""
        if len(text) > 4000:
            break
    
    total_pages = max(1, (total_games + per_page - 1) // per_page)
    text += f"\n📌 Use /history {page+1} for next page" if page < total_pages else ""
    text += f"\n📌 Use /history {page-1} for previous page" if page > 1 else ""
    
    await update.message.reply_text(text)

# ============ HISTORY PAGE CALLBACK ============

async def history_page_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle history page navigation"""
    query = update.callback_query
    await query.answer()
    
    page = int(query.data.replace('history_page_', ''))
    context.args = [str(page)]
    
    await history_command(update, context)

# ============ CLAIM COMMAND ============

async def claim_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    success, message = db_claim_daily_bonus(user.id)
    
    if success:
        bonus_info = get_daily_bonus_info(user.id)
        progress = "🟢" * (bonus_info['streak'] % 3) + "⚪" * (3 - (bonus_info['streak'] % 3))
        await update.message.reply_text(
            f"""
{get_brand_header()}

✅ {message}

🔥 Streak: {bonus_info['streak']} days
{progress}

🎉 Come back tomorrow!
            """
        )
    else:
        await update.message.reply_text(
            f"""
{get_brand_header()}

⏳ {message}

📌 Already claimed today!
Come back tomorrow.
            """
        )

# ============ SET CURRENCY ============

async def set_currency(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    currency = query.data.replace('currency_', '')
    user_id = update.effective_user.id
    
    set_user_currency(user_id, currency)
    
    await query.edit_message_text(f"✅ Currency set to {currency}!")
    await start(update, context)

# ============ DAILY BONUS MENU ============

async def daily_bonus_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    bonus_info = get_daily_bonus_info(user_id)
    
    keyboard = [
        [InlineKeyboardButton("🎁 Claim Bonus", callback_data="claim_daily_bonus")],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    status_text = "✅ Available Now!" if bonus_info['can_claim'] else "⏳ Check tomorrow"
    
    progress = "🟢" * (bonus_info['streak'] % 3) + "⚪" * (3 - (bonus_info['streak'] % 3))
    
    streak = bonus_info['streak']
    if streak >= 10:
        next_target = "🎉 10 Days Streak Achieved!"
    elif streak >= 3:
        next_target = f"🎯 {10 - streak} more days for ₹15"
    else:
        next_target = f"🎯 {3 - streak} more days for ₹10"
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

💰 DAILY BONUS

🔥 Streak: {bonus_info['streak']} days
📈 Status: {status_text}
🎯 Next: {next_target}

{progress}

📌 Rules:
• Claim daily to build streak
• 3 Days Streak = ₹10 Bonus 🎉
• 10 Days Streak = ₹15 Bonus 🎉
• Miss a day = Reset to Day 1

💡 Tip: Login daily!
        """,
        reply_markup=reply_markup
    )

async def claim_daily_bonus_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    success, message = db_claim_daily_bonus(user_id)
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if success:
        bonus_info = get_daily_bonus_info(user_id)
        progress = "🟢" * (bonus_info['streak'] % 3) + "⚪" * (3 - (bonus_info['streak'] % 3))
        
        await query.edit_message_text(
            f"""
{get_brand_header()}

✅ {message}

🔥 Streak: {bonus_info['streak']} days
{progress}

🎉 Come back tomorrow!
            """,
            reply_markup=reply_markup
        )
    else:
        await query.edit_message_text(
            f"""
{get_brand_header()}

⏳ {message}

📌 Already claimed today!
Come back tomorrow.
            """,
            reply_markup=reply_markup
        )

# ============ SHOW STATS ============

async def show_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show stats from callback query"""
    await stats_command(update, context)

# ============ HISTORY MENU ============

async def history_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show history from callback query"""
    context.args = ['1']
    await history_command(update, context)

async def back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await start(update, context)

async def noop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

# ============ ADMIN PANEL ============

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    if user_id != ADMIN_USER_ID:
        await query.edit_message_text("❌ Unauthorized!")
        return
    
    keyboard = [
        [InlineKeyboardButton("💰 Add Balance", callback_data="admin_add_balance")],
        [InlineKeyboardButton("💵 Give All ₹10", callback_data="admin_give_all")],
        [InlineKeyboardButton("📊 All Users", callback_data="admin_users")],
        [InlineKeyboardButton("🔙 Back", callback_data="back_to_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

👑 ADMIN PANEL

Welcome {ADMIN_USERNAME}!

Select an option:
        """,
        reply_markup=reply_markup
    )

async def admin_add_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    if user_id != ADMIN_USER_ID:
        await query.edit_message_text("❌ Unauthorized!")
        return
    
    await query.edit_message_text(
        f"""
{get_brand_header()}

💰 ADD BALANCE

Usage: /addbalance @username amount
Example: /addbalance @john 100

Amount is in user's currency (INR or USD)
        """
    )

async def admin_addbalance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if user_id != ADMIN_USER_ID:
        await update.message.reply_text("❌ Unauthorized!")
        return
    
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /addbalance @username amount")
        return
    
    username = context.args[0].replace('@', '')
    try:
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Invalid amount!")
        return
    
    conn = get_db()
    c = conn.cursor()
    
    if username.isdigit():
        c.execute('SELECT user_id, currency, first_name FROM users WHERE user_id = ?', (int(username),))
    else:
        c.execute('SELECT user_id, currency, first_name FROM users WHERE username = ?', (username,))
    
    user = c.fetchone()
    if not user:
        await update.message.reply_text(f"❌ User @{username} not found!")
        conn.close()
        return
    
    target_id = user[0]
    currency = user[1]
    first_name = user[2]
    symbol = '₹' if currency == 'INR' else '$'
    
    amount_in_paise = amount * 100
    update_wallet(target_id, amount_in_paise, currency)
    
    balance = get_user_balance(target_id, currency)
    add_transaction(target_id, 'admin_add', amount_in_paise, currency, balance, f"Admin added {symbol}{amount}")
    
    conn.commit()
    conn.close()
    
    await update.message.reply_text(f"✅ Added {symbol}{amount} to @{username}!")
    
    await context.bot.send_message(
        chat_id=target_id,
        text=f"{get_brand_header()}\n\n✅ {symbol}{amount} added to your wallet by admin!"
    )

async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    if user_id != ADMIN_USER_ID:
        await query.edit_message_text("❌ Unauthorized!")
        return
    
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT user_id, username, first_name, currency, wallet_balance_inr, wallet_balance_usd, total_games, total_wins, level FROM users ORDER BY total_wins DESC LIMIT 20')
    users = c.fetchall()
    conn.close()
    
    if not users:
        await query.edit_message_text("📊 No users found.")
        return
    
    text = f"""
{get_brand_header()}

📊 TOP PLAYERS
"""
    
    for idx, u in enumerate(users, 1):
        symbol = '₹' if u[3] == 'INR' else '$'
        balance = u[4] if u[3] == 'INR' else u[5]
        text += f"""
{idx}. @{u[1] or u[2]}
🆔 {u[0]}
💰 {symbol}{balance/100:.2f}
🏆 {u[7]} wins | Level {u[8]}
"""
    
    keyboard = [[InlineKeyboardButton("🔙 Back", callback_data="admin_panel")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(text, reply_markup=reply_markup)

async def admin_give_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    if user_id != ADMIN_USER_ID:
        await query.edit_message_text("❌ Unauthorized!")
        return
    
    await query.edit_message_text("⏳ Adding ₹10 to all users...")
    
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT user_id, currency FROM users')
        users = c.fetchall()
        
        count = 0
        for user in users:
            if user[1] == 'INR':
                update_wallet(user[0], 1000, 'INR')
            else:
                update_wallet(user[0], 1000, 'USD')
            count += 1
        
        conn.close()
        await query.edit_message_text(f"✅ Added ₹10 equivalent to {count} users!")
    except Exception as e:
        await query.edit_message_text(f"❌ Error: {str(e)}")

# ============ TIP COMMAND ============

async def tip_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("❌ Usage: /tip @username amount")
        return
    
    username = context.args[0].replace('@', '')
    try:
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Invalid amount!")
        return
    
    sender_id = update.effective_user.id
    
    try:
        target = None
        try:
            target = await context.bot.get_user_by_username(username)
        except:
            pass
        
        if not target:
            conn = get_db()
            c = conn.cursor()
            c.execute('SELECT user_id FROM users WHERE username = ?', (username,))
            result = c.fetchone()
            conn.close()
            if result:
                try:
                    target = await context.bot.get_chat(result[0])
                except:
                    pass
        
        if not target:
            await update.message.reply_text(f"❌ User @{username} not found.")
            return
        
        currency = get_user_currency(sender_id)
        sender_balance = get_user_balance(sender_id, currency)
        
        if sender_balance < amount * 100:
            symbol = '₹' if currency == 'INR' else '$'
            await update.message.reply_text(f"❌ Insufficient balance! You have {symbol}{sender_balance/100:.2f}")
            return
        
        update_wallet(sender_id, -(amount * 100), currency)
        balance = get_user_balance(sender_id, currency)
        add_transaction(sender_id, 'tip_sent', -(amount * 100), currency, balance, f"Tip sent to @{username}")
        
        target_currency = get_user_currency(target.id)
        update_wallet(target.id, amount * 100, target_currency)
        balance2 = get_user_balance(target.id, target_currency)
        add_transaction(target.id, 'tip_received', amount * 100, target_currency, balance2, f"Tip received from @{update.effective_user.username}")
        
        symbol = '₹' if currency == 'INR' else '$'
        await update.message.reply_text(f"✅ Tipped {symbol}{amount} to @{username}!")
        
        await context.bot.send_message(
            chat_id=target.id,
            text=f"{get_brand_header()}\n\n💝 You received {symbol}{amount} from @{update.effective_user.username}!"
        )
        
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

# ============ ROLL COMMAND ============

async def roll_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    pvp_game = pvp_handler.get_user_game(user_id)
    if pvp_game and pvp_game['is_active'] and not pvp_game['game_over']:
        if pvp_game['current_turn'] == user_id:
            roll_button = [[InlineKeyboardButton("🎲 ROLL DICE NOW!", callback_data=f"pvp_roll_{pvp_game['game_id']}")]]
            roll_markup = InlineKeyboardMarkup(roll_button)
            
            await update.message.reply_text(
                f"""
{get_brand_header()}

🎲 **Click the button below to roll!**
                """,
                reply_markup=roll_markup
            )
        else:
            current_name = pvp_handler.get_current_player_name(pvp_game)
            await update.message.reply_text(
                f"""
{get_brand_header()}

⏳ **Waiting for {current_name} to roll...**

Please wait for your turn.
                """
            )
        return
    
    game_id = game_manager.get_user_game(user_id)
    if not game_id:
        await update.message.reply_text("❌ No active game! Start one with /start")
        return
    
    result = game_manager.make_move(game_id, user_id)
    
    if 'error' in result:
        await update.message.reply_text(f"❌ {result['error']}")
        return
    
    await update.message.reply_text(result['message'])

# ============ SET COMMANDS ============

async def set_commands(app):
    commands = [
        BotCommand("start", "Open main menu"),
        BotCommand("help", "Show all commands"),
        BotCommand("challenge", "Challenge a player @username"),
        BotCommand("roll", "Roll dice in active game"),
        BotCommand("balance", "Check your balance"),
        BotCommand("bal", "Check your balance (shortcut)"),
        BotCommand("history", "View game history"),
        BotCommand("top", "View top players"),
        BotCommand("claim", "Claim daily bonus"),
        BotCommand("tip", "Tip another player @username amount"),
        BotCommand("deposit", "Deposit funds"),
        BotCommand("depo", "Deposit funds (shortcut)"),
        BotCommand("withdraw", "Withdraw funds"),
        BotCommand("wd", "Withdraw funds (shortcut)"),
    ]
    await app.bot.set_my_commands(commands)
# ============ MAIN ============

def main():
    init_db()
    
    request = HTTPXRequest(
        connection_pool_size=8,
        connect_timeout=30.0,
        read_timeout=30.0,
        write_timeout=30.0,
        pool_timeout=30.0,
        http_version="1.1"
    )
    
    app = ApplicationBuilder().token(BOT_TOKEN).request(request).build()
    
    app.post_init = set_commands
    
    # Commands
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("challenge", challenge_command))
    app.add_handler(CommandHandler("roll", roll_command))
    app.add_handler(CommandHandler("balance", balance_command))
    app.add_handler(CommandHandler("bal", balance_command))
    app.add_handler(CommandHandler("history", history_command))
    app.add_handler(CommandHandler("top", top_players_menu))
    app.add_handler(CommandHandler("claim", claim_command))
    app.add_handler(CommandHandler("tip", tip_command))
    app.add_handler(CommandHandler("deposit", deposit_command))
    app.add_handler(CommandHandler("depo", deposit_command))
    app.add_handler(CommandHandler("withdraw", withdraw_command))
    app.add_handler(CommandHandler("wd", withdraw_command))
    app.add_handler(CommandHandler("payment_menu", payment_menu))
    
    # Admin Commands
    app.add_handler(CommandHandler("addbalance", admin_addbalance))
    
    # Callbacks
    # Callbacks
    app.add_handler(CallbackQueryHandler(set_currency, pattern="^currency_"))
    app.add_handler(CallbackQueryHandler(challenge_step1, pattern="^challenge_step1$"))
    app.add_handler(CallbackQueryHandler(challenge_bet_selected, pattern="^challenge_bet_"))
    app.add_handler(CallbackQueryHandler(challenge_rounds_selected, pattern="^challenge_rounds_"))
    app.add_handler(CallbackQueryHandler(handle_challenge_response, pattern="^(accept|decline)_"))
    app.add_handler(CallbackQueryHandler(pvp_roll_button, pattern="^pvp_roll_"))
    app.add_handler(CallbackQueryHandler(bot_menu, pattern="^bot_menu$"))
    app.add_handler(CallbackQueryHandler(start_game, pattern="^game_type_"))
    app.add_handler(CallbackQueryHandler(payment_menu, pattern="^payment_menu$"))
    app.add_handler(CallbackQueryHandler(daily_bonus_menu, pattern="^daily_bonus_menu$"))
    app.add_handler(CallbackQueryHandler(claim_daily_bonus_handler, pattern="^claim_daily_bonus$"))
    app.add_handler(CallbackQueryHandler(history_menu, pattern="^history$"))
    app.add_handler(CallbackQueryHandler(history_page_callback, pattern="^history_page_"))
    app.add_handler(CallbackQueryHandler(top_players_menu, pattern="^top_players_menu$"))
    app.add_handler(CallbackQueryHandler(top_players, pattern="^top_(all|daily|weekly|monthly)$"))
    app.add_handler(CallbackQueryHandler(help_command, pattern="^help$"))
    app.add_handler(CallbackQueryHandler(back_to_main, pattern="^back_to_main$"))
    app.add_handler(CallbackQueryHandler(noop, pattern="^noop$"))
    
    # Admin Callbacks
    app.add_handler(CallbackQueryHandler(admin_panel, pattern="^admin_panel$"))
    app.add_handler(CallbackQueryHandler(admin_add_balance, pattern="^admin_add_balance$"))
    app.add_handler(CallbackQueryHandler(admin_give_all, pattern="^admin_give_all$"))
    app.add_handler(CallbackQueryHandler(admin_users, pattern="^admin_users$"))
    
    # Message handler for custom bet
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, challenge_custom_bet_handler))
    
    print(f"{BRAND_NAME} - Game Bot is starting...")
    print(f"👑 Admin: {ADMIN_USERNAME}")
    print(f"💳 Payment Bot: {PAYMENT_BOT_LINK}")
    print("📌 Using shared database: payment_bot.db")
    print("📌 Payment Limits: INR ₹100-₹5,000 | USD $0.10-$20")
    print("📌 Features: Stats, History (with pages), Top Players (Daily/Weekly/Monthly/All Time)")
    print("✅ Bot is running!")
    app.run_polling()

if __name__ == '__main__':
    main()